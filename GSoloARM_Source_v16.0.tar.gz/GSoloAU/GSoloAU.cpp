#include "GSoloAU.h"

#include <vector>
#include <cmath>

// MARK: - GSoloAU Implementation

GSoloAU::GSoloAU(AudioComponentInstance inComponentInstance)
: mComponentInstance(inComponentInstance)
, mVolume(1.0f)
, mPan(0.5f)
, mSoloMode(false)
, mPhase(0.0f)
, mNextNoteID(1)
, mCocoaView(nullptr)
{
    mOutputFormat.mSampleRate = 44100.0;
    mOutputFormat.mFormatID = kAudioFormatLinearPCM;
    mOutputFormat.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked | kAudioFormatFlagIsNonInterleaved;
    mOutputFormat.mBytesPerPacket = sizeof(Float32);
    mOutputFormat.mFramesPerPacket = 1;
    mOutputFormat.mBytesPerFrame = sizeof(Float32);
    mOutputFormat.mChannelsPerFrame = 2;
    mOutputFormat.mBitsPerChannel = 8 * sizeof(Float32);
}

GSoloAU::~GSoloAU()
{
    // ARC will handle the Cocoa view release automatically
}

// Static factory function implementation
void* GSoloAU::CreateCocoaView(void* au)
{
    // This function is defined in GSoloAU_CocoaView.mm
    extern "C" void* _CreateGSoloAUCocoaView(void* au);
    return _CreateGSoloAUCocoaView(au);
}

// MARK: - Audio Unit Methods

OSStatus GSoloAU::Initialize()
{
    // Create the Cocoa view (defined in GSoloAU_CocoaView.mm)
    mCocoaView = CreateCocoaView(this);
    return noErr;
}

OSStatus GSoloAU::GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable)
{
    switch (inID) {
        case kAudioUnitProperty_ClassInfo:
            outDataSize = sizeof(CFStringRef);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_StreamFormat:
            outDataSize = sizeof(AudioStreamBasicDescription);
            outWritable = true;
            return noErr;

        case kAudioUnitProperty_ElementCount:
            outDataSize = sizeof(UInt32);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_Latency:
            outDataSize = sizeof(Float64);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_MaximumFramesPerSlice:
            outDataSize = sizeof(UInt32);
            outWritable = true;
            return noErr;

        case kAudioUnitProperty_ParameterList:
            outDataSize = sizeof(AudioUnitParameterID) * 3;
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_ParameterInfo:
            outDataSize = sizeof(AudioUnitParameterInfo);
            outWritable = false;
            return noErr;

        case kMusicDeviceProperty_InstrumentCount:
            outDataSize = sizeof(UInt32);
            outWritable = false;
            return noErr;

        case kMusicDeviceProperty_InstrumentName:
            outDataSize = sizeof(CFStringRef);
            outWritable = false;
            return noErr;

        case kGSoloAU_Property_Volume:
            outDataSize = sizeof(Float32);
            outWritable = true;
            return noErr;

        case kGSoloAU_Property_Pan:
            outDataSize = sizeof(Float32);
            outWritable = true;
            return noErr;

        case kGSoloAU_Property_SoloMode:
            outDataSize = sizeof(Boolean);
            outWritable = true;
            return noErr;

        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

OSStatus GSoloAU::GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData)
{
    switch (inID) {
        case kAudioUnitProperty_ClassInfo:
            *(CFStringRef*)outData = CFSTR("com.soundlib.gsolo");
            CFRetain(*(CFStringRef*)outData);
            return noErr;

        case kAudioUnitProperty_StreamFormat:
            if (inScope == kAudioUnitScope_Output && inElement == 0) {
                *(AudioStreamBasicDescription*)outData = mOutputFormat;
                return noErr;
            }
            return kAudioUnitErr_InvalidElement;

        case kAudioUnitProperty_ElementCount:
            if (inScope == kAudioUnitScope_Input || inScope == kAudioUnitScope_Output) {
                *(UInt32*)outData = 1;
                return noErr;
            }
            return kAudioUnitErr_InvalidScope;

        case kAudioUnitProperty_Latency:
            *(Float64*)outData = 0.0;
            return noErr;

        case kAudioUnitProperty_MaximumFramesPerSlice:
            *(UInt32*)outData = 4096;
            return noErr;

        case kAudioUnitProperty_ParameterList:
            {
                AudioUnitParameterID params[] = {
                    kGSoloAU_Param_Volume,
                    kGSoloAU_Param_Pan,
                    kGSoloAU_Param_Solo
                };
                memcpy(outData, params, sizeof(params));
                return noErr;
            }

        case kMusicDeviceProperty_InstrumentCount:
            *(UInt32*)outData = 1;
            return noErr;

        case kMusicDeviceProperty_InstrumentName:
            *(CFStringRef*)outData = CFSTR("G-Solo");
            CFRetain(*(CFStringRef*)outData);
            return noErr;

        case kGSoloAU_Property_Volume:
            *(Float32*)outData = mVolume;
            return noErr;

        case kGSoloAU_Property_Pan:
            *(Float32*)outData = mPan;
            return noErr;

        case kGSoloAU_Property_SoloMode:
            *(Boolean*)outData = mSoloMode;
            return noErr;

        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

OSStatus GSoloAU::SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize)
{
    switch (inID) {
        case kAudioUnitProperty_StreamFormat:
            if (inScope == kAudioUnitScope_Output && inElement == 0 && inDataSize == sizeof(AudioStreamBasicDescription)) {
                mOutputFormat = *(const AudioStreamBasicDescription*)inData;
                return noErr;
            }
            return kAudioUnitErr_InvalidElement;

        case kGSoloAU_Property_Volume:
            if (inDataSize == sizeof(Float32)) {
                mVolume = *(const Float32*)inData;
                if (mVolume < 0.0f) mVolume = 0.0f;
                if (mVolume > 1.0f) mVolume = 1.0f;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        case kGSoloAU_Property_Pan:
            if (inDataSize == sizeof(Float32)) {
                mPan = *(const Float32*)inData;
                if (mPan < 0.0f) mPan = 0.0f;
                if (mPan > 1.0f) mPan = 1.0f;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        case kGSoloAU_Property_SoloMode:
            if (inDataSize == sizeof(Boolean)) {
                mSoloMode = *(const Boolean*)inData;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

OSStatus GSoloAU::GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo)
{
    CFStringRef name = nullptr;
    AudioUnitParameterUnit unit = kAudioUnitParameterUnit_Generic;
    Float32 minValue = 0.0f;
    Float32 maxValue = 1.0f;
    Float32 defaultValue = 0.5f;

    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            name = CFSTR("Volume");
            unit = kAudioUnitParameterUnit_LinearGain;
            minValue = 0.0f;
            maxValue = 1.0f;
            defaultValue = 1.0f;
            break;

        case kGSoloAU_Param_Pan:
            name = CFSTR("Pan");
            unit = kAudioUnitParameterUnit_Pan;
            minValue = 0.0f;
            maxValue = 1.0f;
            defaultValue = 0.5f;
            break;

        case kGSoloAU_Param_Solo:
            name = CFSTR("Solo Mode");
            unit = kAudioUnitParameterUnit_Boolean;
            minValue = 0.0f;
            maxValue = 1.0f;
            defaultValue = 0.0f;
            break;

        default:
            return kAudioUnitErr_InvalidParameter;
    }

    outParameterInfo.flags = kAudioUnitParameterFlag_Global | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
    outParameterInfo.minValue = minValue;
    outParameterInfo.maxValue = maxValue;
    outParameterInfo.defaultValue = defaultValue;
    outParameterInfo.unit = unit;
    outParameterInfo.cfNameString = name;

    return noErr;
}

OSStatus GSoloAU::GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            outValue = mVolume;
            return noErr;

        case kGSoloAU_Param_Pan:
            outValue = mPan;
            return noErr;

        case kGSoloAU_Param_Solo:
            outValue = mSoloMode ? 1.0f : 0.0f;
            return noErr;

        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            mVolume = inValue;
            if (mVolume < 0.0f) mVolume = 0.0f;
            if (mVolume > 1.0f) mVolume = 1.0f;
            return noErr;

        case kGSoloAU_Param_Pan:
            mPan = inValue;
            if (mPan < 0.0f) mPan = 0.0f;
            if (mPan > 1.0f) mPan = 1.0f;
            return noErr;

        case kGSoloAU_Param_Solo:
            mSoloMode = (inValue > 0.5f);
            return noErr;

        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams)
{
    if (mSoloMode) {
        // Solo mode: stop all previous notes
        for (auto& note : mActiveNotes) {
            StopNote(inGroupID, note.noteID, inOffsetSampleFrame);
        }
        mActiveNotes.clear();
    }

    ActiveNote newNote;
    newNote.noteID = mNextNoteID++;
    newNote.noteNumber = inParams.mPitch;
    newNote.velocity = inParams.mVelocity;
    newNote.frequency = 440.0 * pow(2.0, (inParams.mPitch - 69) / 12.0);
    newNote.phase = 0.0;

    mActiveNotes.push_back(newNote);
    *outNoteInstanceID = newNote.noteID;

    return noErr;
}

OSStatus GSoloAU::StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame)
{
    for (auto it = mActiveNotes.begin(); it != mActiveNotes.end(); ++it) {
        if (it->noteID == inNoteInstanceID) {
            mActiveNotes.erase(it);
            break;
        }
    }
    return noErr;
}

OSStatus GSoloAU::Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData)
{
    if (inOutputBusNumber != 0) return noErr;

    Float32* leftBuffer = (Float32*)ioData.mBuffers[0].mData;
    Float32* rightBuffer = (Float32*)ioData.mBuffers[1].mData;

    // Clear buffers
    memset(leftBuffer, 0, inNumberFrames * sizeof(Float32));
    memset(rightBuffer, 0, inNumberFrames * sizeof(Float32));

    // Generate simple sine wave for each active note
    for (auto& note : mActiveNotes) {
        Float64 phaseIncrement = (2.0 * M_PI * note.frequency) / mOutputFormat.mSampleRate;
        Float64 phase = note.phase;

        Float32 volume = mVolume * (note.velocity / 127.0f);
        Float32 pan = mPan;
        Float32 leftGain = (pan <= 0.5f) ? 1.0f : (1.0f - pan) * 2.0f;
        Float32 rightGain = (pan >= 0.5f) ? 1.0f : pan * 2.0f;

        for (UInt32 i = 0; i < inNumberFrames; i++) {
            Float32 sample = sin(phase) * volume;
            leftBuffer[i] += sample * leftGain;
            rightBuffer[i] += sample * rightGain;
            phase += phaseIncrement;
        }

        note.phase = phase;
        if (note.phase > 2.0 * M_PI) note.phase -= 2.0 * M_PI;
    }

    return noErr;
}

void GSoloAU::SetSoloMode(Boolean inSolo)
{
    mSoloMode = inSolo;
}

Boolean GSoloAU::GetSoloMode() const
{
    return mSoloMode;
}

void* GSoloAU::GetView()
{
    return mCocoaView;
}

void GSoloAU::SetView(void* inView)
{
    // ARC will handle retain/release automatically
    mCocoaView = inView;
}

// MARK: - C Function Implementations

extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance)
{
    return new GSoloAU(inComponentInstance);
}
