#include <AudioToolbox/AudioToolbox.h>
#include "GSoloAU.h"

// MARK: - Component Entry Point

// Component description
#define kGSoloAU_ComponentType kAudioUnitType_MusicDevice
#define kGSoloAU_ComponentSubType 'AkGs'
#define kGSoloAU_ComponentManufacturer 'AkGs'

// MARK: - Audio Unit Component Methods

// Initialize
OSStatus GSoloAU_InitializeEntry(AudioComponentInstance ci, void* self)
{
    return ((GSoloAU*)self)->Initialize();
}

// Uninitialize
OSStatus GSoloAU_UninitializeEntry(AudioComponentInstance ci, void* self)
{
    return ((GSoloAU*)self)->Uninitialize();
}

// GetPropertyInfo
OSStatus GSoloAU_GetPropertyInfoEntry(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32* outDataSize, Boolean* outWritable)
{
    return ((GSoloAU*)self)->GetPropertyInfo(inID, inScope, inElement, *outDataSize, *outWritable);
}

// GetProperty
OSStatus GSoloAU_GetPropertyEntry(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData)
{
    return ((GSoloAU*)self)->GetProperty(inID, inScope, inElement, outData);
}

// SetProperty
OSStatus GSoloAU_SetPropertyEntry(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize)
{
    return ((GSoloAU*)self)->SetProperty(inID, inScope, inElement, inData, inDataSize);
}

// GetParameterInfo
OSStatus GSoloAU_GetParameterInfoEntry(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo* outParameterInfo)
{
    return ((GSoloAU*)self)->GetParameterInfo(inScope, inParameterID, *outParameterInfo);
}

// GetParameterValue
OSStatus GSoloAU_GetParameterValueEntry(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32* outValue)
{
    return ((GSoloAU*)self)->GetParameterValue(inScope, inParameterID, *outValue);
}

// SetParameterValue
OSStatus GSoloAU_SetParameterValueEntry(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue)
{
    return ((GSoloAU*)self)->SetParameterValue(inScope, inParameterID, inValue);
}

// StartNote
OSStatus GSoloAU_StartNoteEntry(AudioComponentInstance ci, void* self, MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams* inParams)
{
    return ((GSoloAU*)self)->StartNote(inInstrument, inGroupID, outNoteInstanceID, inOffsetSampleFrame, *inParams);
}

// StopNote
OSStatus GSoloAU_StopNoteEntry(AudioComponentInstance ci, void* self, MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame)
{
    return ((GSoloAU*)self)->StopNote(inGroupID, inNoteInstanceID, inOffsetSampleFrame);
}

// Render
OSStatus GSoloAU_RenderEntry(AudioComponentInstance ci, void* self, AudioUnitRenderActionFlags* ioActionFlags, const AudioTimeStamp* inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList* ioData)
{
    return ((GSoloAU*)self)->Render(*ioActionFlags, *inTimeStamp, inOutputBusNumber, inNumberFrames, *ioData);
}

// Reset
OSStatus GSoloAU_ResetEntry(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitElement inElement)
{
    return ((GSoloAU*)self)->Reset(inScope, inElement);
}

// GetView
OSStatus GSoloAU_GetViewEntry(AudioComponentInstance ci, void* self, CFStringRef inViewType, void* outView)
{
    if (CFEqual(inViewType, kAudioUnitViewType_Cocoa)) {
        *(NSView**)outView = ((GSoloAU*)self)->GetView();
        return noErr;
    }
    return kAudioUnitErr_InvalidPropertyValue;
}

// MARK: - Component Dispatch Table

AudioComponentMethod GSoloAU_Methods[] = {
    {kAudioUnitInitializeSelect, (AudioComponentMethodFunction)GSoloAU_InitializeEntry},
    {kAudioUnitUninitializeSelect, (AudioComponentMethodFunction)GSoloAU_UninitializeEntry},
    {kAudioUnitGetPropertyInfoSelect, (AudioComponentMethodFunction)GSoloAU_GetPropertyInfoEntry},
    {kAudioUnitGetPropertySelect, (AudioComponentMethodFunction)GSoloAU_GetPropertyEntry},
    {kAudioUnitSetPropertySelect, (AudioComponentMethodFunction)GSoloAU_SetPropertyEntry},
    {kAudioUnitGetParameterInfoSelect, (AudioComponentMethodFunction)GSoloAU_GetParameterInfoEntry},
    {kAudioUnitGetParameterValueSelect, (AudioComponentMethodFunction)GSoloAU_GetParameterValueEntry},
    {kAudioUnitSetParameterValueSelect, (AudioComponentMethodFunction)GSoloAU_SetParameterValueEntry},
    {kAudioUnitStartNoteSelect, (AudioComponentMethodFunction)GSoloAU_StartNoteEntry},
    {kAudioUnitStopNoteSelect, (AudioComponentMethodFunction)GSoloAU_StopNoteEntry},
    {kAudioUnitRenderSelect, (AudioComponentMethodFunction)GSoloAU_RenderEntry},
    {kAudioUnitResetSelect, (AudioComponentMethodFunction)GSoloAU_ResetEntry},
    {kAudioUnitGetUIComponentSelect, (AudioComponentMethodFunction)GSoloAU_GetViewEntry},
    {0, nullptr}
};

// MARK: - Component Description

extern "C" AudioComponentDescription GSoloAU_ComponentDescription = {
    kGSoloAU_ComponentManufacturer,
    kGSoloAU_ComponentType,
    kGSoloAU_ComponentSubType,
    0,
    1
};

// MARK: - Component Entry

extern "C" OSStatus GSoloAU_ComponentEntry(AudioComponentInstance ci, void* self, AudioComponentMethod method, void* args, UInt32 argSize)
{
    // This function is called by AudioUnit framework
    // We need to implement the dispatch mechanism
    
    switch (method.selector) {
        case kAudioUnitInitializeSelect:
            return GSoloAU_InitializeEntry(ci, self);
        case kAudioUnitUninitializeSelect:
            return GSoloAU_UninitializeEntry(ci, self);
        case kAudioUnitGetPropertyInfoSelect:
            return GSoloAU_GetPropertyInfoEntry(ci, self, 
                ((AudioUnitGetPropertyInfoArgs*)args)->inID,
                ((AudioUnitGetPropertyInfoArgs*)args)->inScope,
                ((AudioUnitGetPropertyInfoArgs*)args)->inElement,
                ((AudioUnitGetPropertyInfoArgs*)args)->outDataSize,
                ((AudioUnitGetPropertyInfoArgs*)args)->outWritable);
        // ... other selectors
        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

// MARK: - Component Factory

extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance)
{
    return new GSoloAU(inComponentInstance);
}
