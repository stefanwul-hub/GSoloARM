#pragma once

#include <AudioToolbox/AudioToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#include <vector>
#include <cmath>

// Forward declarations
@class NSView;

// Component description - MATCHES ORIGINAL
#define kGSoloAU_ComponentType kAudioUnitType_MusicDevice
#define kGSoloAU_ComponentSubType 'AkGs'  // Same as original G-Solo
#define kGSoloAU_ComponentManufacturer 'AkGs'  // Same as original

// Property IDs
enum {
    kGSoloAU_Property_Program = 1000,
    kGSoloAU_Property_ProgramName,
    kGSoloAU_Property_ProgramList,
    kGSoloAU_Property_LoadedSample,
    kGSoloAU_Property_PlayState,
    kGSoloAU_Property_Volume,
    kGSoloAU_Property_Pan,
    kGSoloAU_Property_PitchBend,
    kGSoloAU_Property_SoloMode
};

// Parameter IDs
enum {
    kGSoloAU_Param_Volume = 0,
    kGSoloAU_Param_Pan = 1,
    kGSoloAU_Param_PitchBend = 2,
    kGSoloAU_Param_Expression = 3,
    kGSoloAU_Param_Solo = 4
};

// Active note structure
struct ActiveNote {
    UInt32 noteID;
    UInt32 noteNumber;
    Float64 phase;
    Float64 frequency;
    Float64 velocity;
    UInt64 startFrame;
};

// Audio Unit class - Pure C++ implementation
class GSoloAU {
public:
    GSoloAU(AudioComponentInstance inComponentInstance);
    ~GSoloAU();

    // Audio Unit methods
    OSStatus Initialize();
    OSStatus Uninitialize();
    OSStatus GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable);
    OSStatus GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData);
    OSStatus SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize);
    OSStatus GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo);
    OSStatus GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue);
    OSStatus SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue);
    OSStatus StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams);
    OSStatus StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame);
    OSStatus Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData);
    OSStatus Reset(AudioUnitScope inScope, AudioUnitElement inElement);

    // Solo mode
    void SetSoloMode(Boolean inSolo);
    Boolean GetSoloMode() const;

    // View access
    NSView* GetView();
    void SetView(NSView* inView);

    // Audio Unit component instance
    AudioComponentInstance GetComponentInstance() const { return mComponentInstance; }

private:
    std::vector<ActiveNote> mActiveNotes;
    UInt32 mCurrentProgram;
    Float32 mVolume;
    Float32 mPan;
    Float32 mPitchBend;
    Boolean mSoloMode;
    Float64 mPhase;
    Float64 mFrequency;
    UInt32 mMaxFramesPerSlice;
    
    NSView* mCocoaView;
    AudioComponentInstance mComponentInstance;
    AudioStreamBasicDescription mOutputFormat;
    
    NoteInstanceID mNextNoteID;
};

// C function declarations for Audio Unit factory
extern "C" {
    void* GSoloAU_Create(AudioComponentInstance inComponentInstance);
    OSStatus GSoloAU_Initialize(void* self);
    OSStatus GSoloAU_Uninitialize(void* self);
    OSStatus GSoloAU_GetPropertyInfo(void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32* outDataSize, Boolean* outWritable);
    OSStatus GSoloAU_GetProperty(void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData);
    OSStatus GSoloAU_SetProperty(void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize);
    OSStatus GSoloAU_GetParameterInfo(void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo* outParameterInfo);
    OSStatus GSoloAU_GetParameterValue(void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32* outValue);
    OSStatus GSoloAU_SetParameterValue(void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue);
    OSStatus GSoloAU_StartNote(void* self, MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams* inParams);
    OSStatus GSoloAU_StopNote(void* self, MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame);
    OSStatus GSoloAU_Render(void* self, AudioUnitRenderActionFlags* ioActionFlags, const AudioTimeStamp* inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList* ioData);
    OSStatus GSoloAU_Reset(void* self, AudioUnitScope inScope, AudioUnitElement inElement);
}
