#include "GSoloAU.h"
#include <vector>
#include <cmath>

// Forward declaration for the Cocoa view
@class GSoloAU_CocoaView;

// MARK: - Constants

#define kGSoloAU_Version 0x00010000

// MARK: - GSoloAU Implementation

GSoloAU::GSoloAU(AudioComponentInstance inComponentInstance)
: mComponentInstance(inComponentInstance)
, mCurrentProgram(0)
, mVolume(1.0f)
, mPan(0.5f)
, mPitchBend(0.0f)
, mSoloMode(false)
, mPhase(0.0f)
, mFrequency(440.0f)
, mMaxFramesPerSlice(4096)
, mCocoaView(nullptr)
, mNextNoteID(1)
{
    // Initialize output format
    mOutputFormat.mSampleRate = 44100.0;
    mOutputFormat.mFormatID = kAudioFormatLinearPCM;
    mOutputFormat.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked | kAudioFormatFlagIsNonInterleaved;
    mOutputFormat.mBytesPerPacket = sizeof(Float32);
    mOutputFormat.mFramesPerPacket = 1;
    mOutputFormat.mBytesPerFrame = sizeof(Float32);
    mOutputFormat.mChannelsPerFrame = 2;
    mOutputFormat.mBitsPerChannel = 8 * sizeof(Float32);
}

GSoloAU::~GSoloAU()
{
    if (mCocoaView) {
        [(NSObject*)mCocoaView release];
    }
}

// MARK: - Audio Unit Methods

OSStatus GSoloAU::Initialize()
{
    // Initialize the Cocoa view
    mCocoaView = [[GSoloAU_CocoaView alloc] initWithAudioUnit:this];
    return noErr;
}

OSStatus GSoloAU::Uninitialize()
{
    if (mCocoaView) {
        [(NSObject*)mCocoaView release];
        mCocoaView = nullptr;
    }
    mActiveNotes.clear();
    return noErr;
}

OSStatus GSoloAU::GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable)
{
    switch (inID) {
        case kAudioUnitProperty_ClassInfo:
            outDataSize = sizeof(CFStringRef);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_MakeConnection:
            outDataSize = sizeof(AUConnection);
            outWritable = true;
            return noErr;

        case kAudioUnitProperty_StreamFormat:
            outDataSize = sizeof(AudioStreamBasicDescription);
            outWritable = true;
            return noErr;

        case kAudioUnitProperty_ElementCount:
            outDataSize = sizeof(UInt32);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_Latency:
            outDataSize = sizeof(Float64);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_SupportedNumChannelsForInput:
        case kAudioUnitProperty_SupportedNumChannelsForOutput:
            outDataSize = sizeof(AUChannelInfo);
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_MaximumFramesPerSlice:
            outDataSize = sizeof(UInt32);
            outWritable = true;
            return noErr;

        case kAudioUnitProperty_ParameterList:
            outDataSize = sizeof(AudioUnitParameterID) * 5;
            outWritable = false;
            return noErr;

        case kAudioUnitProperty_ParameterInfo:
            outDataSize = sizeof(AudioUnitParameterInfo);
            outWritable = false;
            return noErr;

        case kMusicDeviceProperty_InstrumentCount:
            outDataSize = sizeof(UInt32);
            outWritable = false;
            return noErr;

        case kMusicDeviceProperty_InstrumentName:
            outDataSize = sizeof(CFStringRef);
            outWritable = false;
            return noErr;

        // G-Solo specific properties
        case kGSoloAU_Property_Volume:
            outDataSize = sizeof(Float32);
            outWritable = true;
            return noErr;

        case kGSoloAU_Property_Pan:
            outDataSize = sizeof(Float32);
            outWritable = true;
            return noErr;

        case kGSoloAU_Property_SoloMode:
            outDataSize = sizeof(Boolean);
            outWritable = true;
            return noErr;

        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

OSStatus GSoloAU::GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData)
{
    switch (inID) {
        case kAudioUnitProperty_ClassInfo:
            *(CFStringRef*)outData = CFSTR("com.soundlib.gsolo");
            CFRetain(*(CFStringRef*)outData);
            return noErr;

        case kAudioUnitProperty_StreamFormat:
            if (inScope == kAudioUnitScope_Output && inElement == 0) {
                *(AudioStreamBasicDescription*)outData = mOutputFormat;
                return noErr;
            }
            return kAudioUnitErr_InvalidElement;

        case kAudioUnitProperty_ElementCount:
            if (inScope == kAudioUnitScope_Input || inScope == kAudioUnitScope_Output) {
                *(UInt32*)outData = 1;
                return noErr;
            }
            return kAudioUnitErr_InvalidScope;

        case kAudioUnitProperty_Latency:
            *(Float64*)outData = 0.0;
            return noErr;

        case kAudioUnitProperty_MaximumFramesPerSlice:
            *(UInt32*)outData = mMaxFramesPerSlice;
            return noErr;

        case kAudioUnitProperty_ParameterList:
            {
                AudioUnitParameterID params[] = {
                    kGSoloAU_Param_Volume,
                    kGSoloAU_Param_Pan,
                    kGSoloAU_Param_PitchBend,
                    kGSoloAU_Param_Expression,
                    kGSoloAU_Param_Solo
                };
                memcpy(outData, params, sizeof(params));
                return noErr;
            }

        case kMusicDeviceProperty_InstrumentCount:
            *(UInt32*)outData = 1;
            return noErr;

        case kMusicDeviceProperty_InstrumentName:
            *(CFStringRef*)outData = CFSTR("G-Solo");
            CFRetain(*(CFStringRef*)outData);
            return noErr;

        case kGSoloAU_Property_Volume:
            *(Float32*)outData = mVolume;
            return noErr;

        case kGSoloAU_Property_Pan:
            *(Float32*)outData = mPan;
            return noErr;

        case kGSoloAU_Property_SoloMode:
            *(Boolean*)outData = mSoloMode;
            return noErr;

        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

OSStatus GSoloAU::SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize)
{
    switch (inID) {
        case kAudioUnitProperty_StreamFormat:
            if (inScope == kAudioUnitScope_Output && inElement == 0 && inDataSize == sizeof(AudioStreamBasicDescription)) {
                mOutputFormat = *(const AudioStreamBasicDescription*)inData;
                return noErr;
            }
            return kAudioUnitErr_InvalidElement;

        case kAudioUnitProperty_MaximumFramesPerSlice:
            if (inDataSize == sizeof(UInt32)) {
                mMaxFramesPerSlice = *(const UInt32*)inData;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        case kGSoloAU_Property_Volume:
            if (inDataSize == sizeof(Float32)) {
                mVolume = *(const Float32*)inData;
                if (mVolume < 0.0f) mVolume = 0.0f;
                if (mVolume > 1.0f) mVolume = 1.0f;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        case kGSoloAU_Property_Pan:
            if (inDataSize == sizeof(Float32)) {
                mPan = *(const Float32*)inData;
                if (mPan < 0.0f) mPan = 0.0f;
                if (mPan > 1.0f) mPan = 1.0f;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        case kGSoloAU_Property_SoloMode:
            if (inDataSize == sizeof(Boolean)) {
                mSoloMode = *(const Boolean*)inData;
                return noErr;
            }
            return kAudioUnitErr_InvalidPropertyValue;

        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

OSStatus GSoloAU::GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            outParameterInfo.parameterID = kGSoloAU_Param_Volume;
            outParameterInfo.parameterType = kAudioUnitParameterType_LinearGain;
            outParameterInfo.flags = kAudioUnitParameterFlag_Global | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 1.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_LinearGain;
            CFRetain(CFSTR("Volume"));
            outParameterInfo.cfNameString = CFSTR("Volume");
            return noErr;

        case kGSoloAU_Param_Pan:
            outParameterInfo.parameterID = kGSoloAU_Param_Pan;
            outParameterInfo.parameterType = kAudioUnitParameterType_Pan;
            outParameterInfo.flags = kAudioUnitParameterFlag_Global | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 0.5f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Pan;
            outParameterInfo.cfNameString = CFSTR("Pan");
            return noErr;

        case kGSoloAU_Param_PitchBend:
            outParameterInfo.parameterID = kGSoloAU_Param_PitchBend;
            outParameterInfo.parameterType = kAudioUnitParameterType_PitchBend;
            outParameterInfo.flags = kAudioUnitParameterFlag_Global | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = -1.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 0.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Cents;
            outParameterInfo.cfNameString = CFSTR("Pitch Bend");
            return noErr;

        case kGSoloAU_Param_Expression:
            outParameterInfo.parameterID = kGSoloAU_Param_Expression;
            outParameterInfo.parameterType = kAudioUnitParameterType_Generic;
            outParameterInfo.flags = kAudioUnitParameterFlag_Global | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 1.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Generic;
            outParameterInfo.cfNameString = CFSTR("Expression");
            return noErr;

        case kGSoloAU_Param_Solo:
            outParameterInfo.parameterID = kGSoloAU_Param_Solo;
            outParameterInfo.parameterType = kAudioUnitParameterType_Generic;
            outParameterInfo.flags = kAudioUnitParameterFlag_Global | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 0.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Boolean;
            outParameterInfo.cfNameString = CFSTR("Solo Mode");
            return noErr;

        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            outValue = mVolume;
            return noErr;

        case kGSoloAU_Param_Pan:
            outValue = mPan;
            return noErr;

        case kGSoloAU_Param_PitchBend:
            outValue = mPitchBend;
            return noErr;

        case kGSoloAU_Param_Expression:
            outValue = 1.0f; // Default expression
            return noErr;

        case kGSoloAU_Param_Solo:
            outValue = mSoloMode ? 1.0f : 0.0f;
            return noErr;

        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            mVolume = inValue;
            if (mVolume < 0.0f) mVolume = 0.0f;
            if (mVolume > 1.0f) mVolume = 1.0f;
            return noErr;

        case kGSoloAU_Param_Pan:
            mPan = inValue;
            if (mPan < 0.0f) mPan = 0.0f;
            if (mPan > 1.0f) mPan = 1.0f;
            return noErr;

        case kGSoloAU_Param_PitchBend:
            mPitchBend = inValue;
            return noErr;

        case kGSoloAU_Param_Expression:
            // Expression not used in this implementation
            return noErr;

        case kGSoloAU_Param_Solo:
            mSoloMode = (inValue > 0.5f);
            return noErr;

        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams)
{
    if (mSoloMode) {
        // Solo mode: stop all previous notes
        for (auto& note : mActiveNotes) {
            StopNote(inGroupID, note.noteID, inOffsetSampleFrame);
        }
        mActiveNotes.clear();
    }

    ActiveNote newNote;
    newNote.noteID = mNextNoteID++;
    newNote.noteNumber = inParams.mPitch;
    newNote.velocity = inParams.mVelocity;
    newNote.startFrame = inOffsetSampleFrame;
    
    // Calculate frequency from MIDI note number
    newNote.frequency = 440.0 * pow(2.0, (inParams.mPitch - 69) / 12.0);
    newNote.phase = 0.0;

    mActiveNotes.push_back(newNote);
    *outNoteInstanceID = newNote.noteID;

    return noErr;
}

OSStatus GSoloAU::StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame)
{
    for (auto it = mActiveNotes.begin(); it != mActiveNotes.end(); ++it) {
        if (it->noteID == inNoteInstanceID) {
            mActiveNotes.erase(it);
            break;
        }
    }
    return noErr;
}

OSStatus GSoloAU::Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData)
{
    if (inOutputBusNumber != 0) return noErr;

    Float32* leftBuffer = (Float32*)ioData.mBuffers[0].mData;
    Float32* rightBuffer = (Float32*)ioData.mBuffers[1].mData;

    // Clear buffers
    memset(leftBuffer, 0, inNumberFrames * sizeof(Float32));
    memset(rightBuffer, 0, inNumberFrames * sizeof(Float32));

    // Generate simple sine wave for each active note
    for (const auto& note : mActiveNotes) {
        Float64 frequency = note.frequency * pow(2.0, mPitchBend / 12.0);
        Float64 phaseIncrement = (2.0 * M_PI * frequency) / mOutputFormat.mSampleRate;
        Float64 phase = note.phase;

        Float32 volume = mVolume;
        Float32 pan = mPan;
        Float32 leftGain = (pan <= 0.5f) ? 1.0f : (1.0f - pan) * 2.0f;
        Float32 rightGain = (pan >= 0.5f) ? 1.0f : pan * 2.0f;

        for (UInt32 i = 0; i < inNumberFrames; i++) {
            Float32 sample = sin(phase) * volume * (note.velocity / 127.0f);
            leftBuffer[i] += sample * leftGain;
            rightBuffer[i] += sample * rightGain;
            phase += phaseIncrement;
        }
    }

    // Update phases
    for (auto& note : mActiveNotes) {
        Float64 frequency = note.frequency * pow(2.0, mPitchBend / 12.0);
        Float64 phaseIncrement = (2.0 * M_PI * frequency) / mOutputFormat.mSampleRate;
        note.phase += phaseIncrement * inNumberFrames;
        if (note.phase > 2.0 * M_PI) note.phase -= 2.0 * M_PI;
    }

    return noErr;
}

OSStatus GSoloAU::Reset(AudioUnitScope inScope, AudioUnitElement inElement)
{
    mActiveNotes.clear();
    mPhase = 0.0;
    return noErr;
}

void GSoloAU::SetSoloMode(Boolean inSolo)
{
    mSoloMode = inSolo;
}

Boolean GSoloAU::GetSoloMode() const
{
    return mSoloMode;
}

NSView* GSoloAU::GetView()
{
    return mCocoaView;
}

void GSoloAU::SetView(NSView* inView)
{
    if (mCocoaView) {
        [(NSObject*)mCocoaView release];
    }
    mCocoaView = inView;
    if (mCocoaView) {
        [(NSObject*)mCocoaView retain];
    }
}

// MARK: - C Function Implementations

extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance)
{
    return new GSoloAU(inComponentInstance);
}

extern "C" OSStatus GSoloAU_Initialize(void* self)
{
    return ((GSoloAU*)self)->Initialize();
}

extern "C" OSStatus GSoloAU_Uninitialize(void* self)
{
    return ((GSoloAU*)self)->Uninitialize();
}

extern "C" OSStatus GSoloAU_GetPropertyInfo(void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32* outDataSize, Boolean* outWritable)
{
    return ((GSoloAU*)self)->GetPropertyInfo(inID, inScope, inElement, *outDataSize, *outWritable);
}

extern "C" OSStatus GSoloAU_GetProperty(void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData)
{
    return ((GSoloAU*)self)->GetProperty(inID, inScope, inElement, outData);
}

extern "C" OSStatus GSoloAU_SetProperty(void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize)
{
    return ((GSoloAU*)self)->SetProperty(inID, inScope, inElement, inData, inDataSize);
}

extern "C" OSStatus GSoloAU_GetParameterInfo(void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo* outParameterInfo)
{
    return ((GSoloAU*)self)->GetParameterInfo(inScope, inParameterID, *outParameterInfo);
}

extern "C" OSStatus GSoloAU_GetParameterValue(void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32* outValue)
{
    return ((GSoloAU*)self)->GetParameterValue(inScope, inParameterID, *outValue);
}

extern "C" OSStatus GSoloAU_SetParameterValue(void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue)
{
    return ((GSoloAU*)self)->SetParameterValue(inScope, inParameterID, inValue);
}

extern "C" OSStatus GSoloAU_StartNote(void* self, MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams* inParams)
{
    return ((GSoloAU*)self)->StartNote(inInstrument, inGroupID, outNoteInstanceID, inOffsetSampleFrame, *inParams);
}

extern "C" OSStatus GSoloAU_StopNote(void* self, MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame)
{
    return ((GSoloAU*)self)->StopNote(inGroupID, inNoteInstanceID, inOffsetSampleFrame);
}

extern "C" OSStatus GSoloAU_Render(void* self, AudioUnitRenderActionFlags* ioActionFlags, const AudioTimeStamp* inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList* ioData)
{
    return ((GSoloAU*)self)->Render(*ioActionFlags, *inTimeStamp, inOutputBusNumber, inNumberFrames, *ioData);
}

extern "C" OSStatus GSoloAU_Reset(void* self, AudioUnitScope inScope, AudioUnitElement inElement)
{
    return ((GSoloAU*)self)->Reset(inScope, inElement);
}
