#include <AudioToolbox/AudioToolbox.h>
#include "GSoloAU.h"

// MARK: - Component Entry Point

// Component description
#define kGSoloAU_ComponentType kAudioUnitType_MusicDevice
#define kGSoloAU_ComponentSubType 'AkGs'
#define kGSoloAU_ComponentManufacturer 'AkGs'

// MARK: - C Function Declarations

extern "C" {
    OSStatus GSoloAU_Initialize(AudioComponentInstance ci, void* self);
    OSStatus GSoloAU_Uninitialize(AudioComponentInstance ci, void* self);
    OSStatus GSoloAU_GetPropertyInfo(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32* outDataSize, Boolean* outWritable);
    OSStatus GSoloAU_GetProperty(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData);
    OSStatus GSoloAU_SetProperty(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize);
    OSStatus GSoloAU_GetParameterInfo(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo* outParameterInfo);
    OSStatus GSoloAU_GetParameterValue(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32* outValue);
    OSStatus GSoloAU_SetParameterValue(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue);
    OSStatus GSoloAU_StartNote(AudioComponentInstance ci, void* self, MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams* inParams);
    OSStatus GSoloAU_StopNote(AudioComponentInstance ci, void* self, MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame);
    OSStatus GSoloAU_Render(AudioComponentInstance ci, void* self, AudioUnitRenderActionFlags* ioActionFlags, const AudioTimeStamp* inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList* ioData);
    OSStatus GSoloAU_Reset(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitElement inElement);
    OSStatus GSoloAU_GetUIComponent(AudioComponentInstance ci, void* self, CFStringRef inViewType, void* outView);
}

// MARK: - C Function Implementations

OSStatus GSoloAU_Initialize(AudioComponentInstance ci, void* self)
{
    return ((GSoloAU*)self)->Initialize();
}

OSStatus GSoloAU_Uninitialize(AudioComponentInstance ci, void* self)
{
    return ((GSoloAU*)self)->Uninitialize();
}

OSStatus GSoloAU_GetPropertyInfo(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32* outDataSize, Boolean* outWritable)
{
    return ((GSoloAU*)self)->GetPropertyInfo(inID, inScope, inElement, *outDataSize, *outWritable);
}

OSStatus GSoloAU_GetProperty(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData)
{
    return ((GSoloAU*)self)->GetProperty(inID, inScope, inElement, outData);
}

OSStatus GSoloAU_SetProperty(AudioComponentInstance ci, void* self, AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize)
{
    return ((GSoloAU*)self)->SetProperty(inID, inScope, inElement, inData, inDataSize);
}

OSStatus GSoloAU_GetParameterInfo(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo* outParameterInfo)
{
    return ((GSoloAU*)self)->GetParameterInfo(inScope, inParameterID, *outParameterInfo);
}

OSStatus GSoloAU_GetParameterValue(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32* outValue)
{
    return ((GSoloAU*)self)->GetParameterValue(inScope, inParameterID, *outValue);
}

OSStatus GSoloAU_SetParameterValue(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue)
{
    return ((GSoloAU*)self)->SetParameterValue(inScope, inParameterID, inValue);
}

OSStatus GSoloAU_StartNote(AudioComponentInstance ci, void* self, MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams* inParams)
{
    return ((GSoloAU*)self)->StartNote(inInstrument, inGroupID, outNoteInstanceID, inOffsetSampleFrame, *inParams);
}

OSStatus GSoloAU_StopNote(AudioComponentInstance ci, void* self, MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame)
{
    return ((GSoloAU*)self)->StopNote(inGroupID, inNoteInstanceID, inOffsetSampleFrame);
}

OSStatus GSoloAU_Render(AudioComponentInstance ci, void* self, AudioUnitRenderActionFlags* ioActionFlags, const AudioTimeStamp* inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList* ioData)
{
    return ((GSoloAU*)self)->Render(*ioActionFlags, *inTimeStamp, inOutputBusNumber, inNumberFrames, *ioData);
}

OSStatus GSoloAU_Reset(AudioComponentInstance ci, void* self, AudioUnitScope inScope, AudioUnitElement inElement)
{
    // Reset is handled by the base class
    return noErr;
}

OSStatus GSoloAU_GetUIComponent(AudioComponentInstance ci, void* self, CFStringRef inViewType, void* outView)
{
    if (CFEqual(inViewType, kAudioUnitViewType_Cocoa)) {
        *(void**)outView = ((GSoloAU*)self)->GetView();
        return noErr;
    }
    return kAudioUnitErr_InvalidPropertyValue;
}

// MARK: - Component Dispatch

// Audio Unit v1 component entry
OSStatus GSoloAU_ComponentDispatch(void* self, AudioComponentMethod method, void* args, UInt32 argSize)
{
    AudioComponentInstance ci = ((GSoloAU*)self)->GetComponentInstance();
    
    switch (method.selector) {
        case kAudioUnitInitializeSelect:
            return GSoloAU_Initialize(ci, self);
        case kAudioUnitUninitializeSelect:
            return GSoloAU_Uninitialize(ci, self);
        case kAudioUnitGetPropertyInfoSelect:
            return GSoloAU_GetPropertyInfo(ci, self, 
                ((AudioUnitGetPropertyInfoArgs*)args)->inID,
                ((AudioUnitGetPropertyInfoArgs*)args)->inScope,
                ((AudioUnitGetPropertyInfoArgs*)args)->inElement,
                ((AudioUnitGetPropertyInfoArgs*)args)->outDataSize,
                ((AudioUnitGetPropertyInfoArgs*)args)->outWritable);
        case kAudioUnitGetPropertySelect:
            return GSoloAU_GetProperty(ci, self,
                ((AudioUnitGetPropertyArgs*)args)->inID,
                ((AudioUnitGetPropertyArgs*)args)->inScope,
                ((AudioUnitGetPropertyArgs*)args)->inElement,
                ((AudioUnitGetPropertyArgs*)args)->outData);
        case kAudioUnitSetPropertySelect:
            return GSoloAU_SetProperty(ci, self,
                ((AudioUnitSetPropertyArgs*)args)->inID,
                ((AudioUnitSetPropertyArgs*)args)->inScope,
                ((AudioUnitSetPropertyArgs*)args)->inElement,
                ((AudioUnitSetPropertyArgs*)args)->inData,
                ((AudioUnitSetPropertyArgs*)args)->inDataSize);
        case kAudioUnitGetParameterInfoSelect:
            return GSoloAU_GetParameterInfo(ci, self,
                ((AudioUnitGetParameterInfoArgs*)args)->inScope,
                ((AudioUnitGetParameterInfoArgs*)args)->inParameterID,
                ((AudioUnitGetParameterInfoArgs*)args)->outParameterInfo);
        case kAudioUnitGetParameterValueSelect:
            return GSoloAU_GetParameterValue(ci, self,
                ((AudioUnitGetParameterValueArgs*)args)->inScope,
                ((AudioUnitGetParameterValueArgs*)args)->inParameterID,
                ((AudioUnitGetParameterValueArgs*)args)->outValue);
        case kAudioUnitSetParameterValueSelect:
            return GSoloAU_SetParameterValue(ci, self,
                ((AudioUnitSetParameterValueArgs*)args)->inScope,
                ((AudioUnitSetParameterValueArgs*)args)->inParameterID,
                ((AudioUnitSetParameterValueArgs*)args)->inValue);
        case kAudioUnitStartNoteSelect:
            return GSoloAU_StartNote(ci, self,
                ((MusicDeviceStartNoteArgs*)args)->inInstrument,
                ((MusicDeviceStartNoteArgs*)args)->inGroupID,
                ((MusicDeviceStartNoteArgs*)args)->outNoteInstanceID,
                ((MusicDeviceStartNoteArgs*)args)->inOffsetSampleFrame,
                ((MusicDeviceStartNoteArgs*)args)->inParams);
        case kAudioUnitStopNoteSelect:
            return GSoloAU_StopNote(ci, self,
                ((MusicDeviceStopNoteArgs*)args)->inGroupID,
                ((MusicDeviceStopNoteArgs*)args)->inNoteInstanceID,
                ((MusicDeviceStopNoteArgs*)args)->inOffsetSampleFrame);
        case kAudioUnitRenderSelect:
            return GSoloAU_Render(ci, self,
                ((AudioUnitRenderArgs*)args)->ioActionFlags,
                ((AudioUnitRenderArgs*)args)->inTimeStamp,
                ((AudioUnitRenderArgs*)args)->inOutputBusNumber,
                ((AudioUnitRenderArgs*)args)->inNumberFrames,
                ((AudioUnitRenderArgs*)args)->ioData);
        case kAudioUnitGetUIComponentSelect:
            return GSoloAU_GetUIComponent(ci, self,
                ((AudioUnitGetUIComponentArgs*)args)->inViewType,
                ((AudioUnitGetUIComponentArgs*)args)->outView);
        default:
            return kAudioUnitErr_InvalidProperty;
    }
}

// MARK: - Component Factory

extern "C" AudioComponentDescription GSoloAU_ComponentDescription = {
    kGSoloAU_ComponentManufacturer,
    kGSoloAU_ComponentType,
    kGSoloAU_ComponentSubType,
    0,
    1
};

// Component factory function
extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance)
{
    return new GSoloAU(inComponentInstance);
}

// Component entry point
extern "C" OSStatus GSoloAU_ComponentEntry(AudioComponentInstance ci, void* self, AudioComponentMethod method, void* args, UInt32 argSize)
{
    if (self == nullptr) {
        // Create instance
        self = GSoloAU_Create(ci);
        if (self == nullptr) return kAudioUnitErr_InvalidProperty;
    }
    return GSoloAU_ComponentDispatch(self, method, args, argSize);
}
