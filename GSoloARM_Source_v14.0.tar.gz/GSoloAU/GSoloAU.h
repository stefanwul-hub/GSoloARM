#pragma once

#include <AudioToolbox/AudioToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#include <vector>
#include <cmath>

// Component description - MATCHES ORIGINAL
#define kGSoloAU_ComponentType kAudioUnitType_MusicDevice
#define kGSoloAU_ComponentSubType 'AkGs'
#define kGSoloAU_ComponentManufacturer 'AkGs'

// Property IDs
enum {
    kGSoloAU_Property_Volume = 2000,
    kGSoloAU_Property_Pan = 2001,
    kGSoloAU_Property_SoloMode = 2002
};

// Parameter IDs
enum {
    kGSoloAU_Param_Volume = 0,
    kGSoloAU_Param_Pan = 1,
    kGSoloAU_Param_Solo = 2
};

// Active note structure
struct ActiveNote {
    UInt32 noteID;
    UInt32 noteNumber;
    Float64 phase;
    Float64 frequency;
    Float64 velocity;
};

// Forward declaration for Objective-C view
#ifdef __OBJC__
@class NSView;
#else
class NSView;
#endif

// Audio Unit class - Pure C++ implementation
class GSoloAU {
public:
    GSoloAU(AudioComponentInstance inComponentInstance);
    ~GSoloAU();

    // Audio Unit methods
    OSStatus Initialize();
    OSStatus GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable);
    OSStatus GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData);
    OSStatus SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize);
    OSStatus GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo);
    OSStatus GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue);
    OSStatus SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue);
    OSStatus StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams);
    OSStatus StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame);
    OSStatus Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData);

    // Solo mode
    void SetSoloMode(Boolean inSolo);
    Boolean GetSoloMode() const;

    // View access
    void* GetView();
    void SetView(void* inView);

    AudioComponentInstance GetComponentInstance() const { return mComponentInstance; }

private:
    std::vector<ActiveNote> mActiveNotes;
    Float32 mVolume;
    Float32 mPan;
    Boolean mSoloMode;
    Float64 mPhase;
    AudioComponentInstance mComponentInstance;
    AudioStreamBasicDescription mOutputFormat;
    UInt32 mNextNoteID;
    void* mCocoaView; // void* to avoid Objective-C in C++ header
    
    // Factory function declaration
    static void* CreateCocoaView(void* au);
};

// C function declarations for Audio Unit factory
extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance);
