#!/bin/bash

# G-Solo ARM64 Audio Unit Installer v7.0
# Compilation avec Makefile (sans xcodebuild)

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo -e "${RED}Error: This script must be run on macOS${NC}"
    exit 1
fi

# Check for Xcode command line tools
if ! xcode-select -p >/dev/null 2>&1; then
    echo -e "${RED}Error: Xcode command line tools not found${NC}"
    echo "Please install Xcode and run: xcode-select --install"
    exit 1
fi

# Check for make
if ! command -v make >/dev/null 2>&1; then
    echo -e "${RED}Error: make not found${NC}"
    echo "Please install Xcode command line tools"
    exit 1
fi

# Check for clang++
if ! command -v clang++ >/dev/null 2>&1; then
    echo -e "${RED}Error: clang++ not found${NC}"
    echo "Please install Xcode command line tools"
    exit 1
fi

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR"
INSTALL_DIR="/Library/Audio/Plug-Ins/Components"
COMPONENT_NAME="GSoloAU.component"
COMPONENT_PATH="$PROJECT_DIR/build/$COMPONENT_NAME"
FINAL_PATH="$INSTALL_DIR/$COMPONENT_NAME"

# Version
VERSION="7.0.0"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}G-Solo ARM64 Audio Unit Installer v$VERSION${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Step 1: Clean
 echo -e "${YELLOW}[1/4] Cleaning previous builds...${NC}"
cd "$PROJECT_DIR"
make clean >/dev/null 2>&1 || true
echo -e "${GREEN}✓ Cleaned${NC}"
echo ""

# Step 2: Compile with Makefile
 echo -e "${YELLOW}[2/4] Compiling with Makefile (Universal Binary ARM64 + x86_64)...${NC}"
cd "$PROJECT_DIR"

if make 2>&1; then
    echo -e "${GREEN}✓ Compilation successful${NC}"
else
    echo -e "${RED}✗ Compilation failed${NC}"
    echo "Please check that Xcode command line tools are installed:"
    echo "  xcode-select --install"
    exit 1
fi
echo ""

# Step 3: Validate
echo -e "${YELLOW}[3/4] Validating Audio Unit...${NC}"
if command -v auval >/dev/null 2>&1; then
    TEMP_VALIDATE_DIR="/tmp/GSoloAU_validate_$$"
    rm -rf "$TEMP_VALIDATE_DIR"
    mkdir -p "$TEMP_VALIDATE_DIR"
    cp -r "$COMPONENT_PATH" "$TEMP_VALIDATE_DIR/"
    
    echo "Running auval validation..."
    if auval -v "$TEMP_VALIDATE_DIR/$COMPONENT_NAME" 2>&1 | grep -q "PASS"; then
        echo -e "${GREEN}✓ Validation passed${NC}"
    else
        echo -e "${YELLOW}⚠ Validation completed (check output above)${NC}"
    fi
    
    rm -rf "$TEMP_VALIDATE_DIR"
else
    echo -e "${YELLOW}⚠ auval not found, skipping validation${NC}"
fi
echo ""

# Step 4: Install
echo -e "${YELLOW}[4/4] Installing to $INSTALL_DIR...${NC}"

# Create install directory if it doesn't exist
if [ ! -d "$INSTALL_DIR" ]; then
    echo "Creating directory: $INSTALL_DIR"
    sudo mkdir -p "$INSTALL_DIR"
fi

# Remove old versions
for old in "$FINAL_PATH" "/Library/Audio/Plug-Ins/Components/G-Solo.component"; do
    if [ -d "$old" ]; then
        echo "Removing old version: $old"
        sudo rm -rf "$old"
    fi
done

# Copy new version
sudo cp -r "$COMPONENT_PATH" "$FINAL_PATH"
sudo chmod -R 755 "$FINAL_PATH"
sudo chown -R root:wheel "$FINAL_PATH"

echo -e "${GREEN}✓ Installed to $FINAL_PATH${NC}"
echo ""

# Verify installation
if [ -f "$FINAL_PATH/Contents/MacOS/GSoloAU" ]; then
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}✓ G-Solo ARM64 installed successfully!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo "Plugin location: $FINAL_PATH"
    echo ""
    echo "To use in your DAW:"
    echo "  1. Restart Ableton Live / Logic Pro"
    echo "  2. Rescan Audio Units"
    echo "  3. Look for 'G-Solo' in the instrument list"
    echo ""
    echo "To uninstall:"
    echo "  sudo rm -rf $FINAL_PATH"
    echo ""
else
    echo -e "${RED}✗ Installation verification failed${NC}"
    exit 1
fi
