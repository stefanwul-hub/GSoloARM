# G-Solo ARM64 Audio Unit

A native ARM64 port of the classic G-Solo Audio Unit plugin for macOS.

## Overview

This is a port of the original **G-Solo** Audio Unit plugin (originally developed by Soundlib, Inc.) to run natively on **Apple Silicon (ARM64)** Macs. The plugin maintains compatibility with Intel-based Macs through Universal Binary support.

## Features

- **Native ARM64 Support**: Runs natively on Apple Silicon Macs
- **Universal Binary**: Includes both ARM64 and x86_64 architectures for compatibility
- **Audio Unit Format**: Works with any AU-compatible DAW (Ableton Live, Logic Pro, GarageBand, etc.)
- **Preserved Interface**: Maintains the look and feel of the original plugin
- **Solo Mode**: Special solo functionality for single-note performance
- **Sample Playback**: Basic sample playback engine (to be expanded)

## Requirements

- macOS 11.0 (Big Sur) or later
- Xcode 14.0 or later
- A compatible DAW that supports Audio Units

## Installation

### Quick Install (Recommended)

Run the install script:

```bash
# Make the script executable
chmod +x install.sh

# Run the installer (requires sudo for installation)
./install.sh
```

The script will:
1. Clean previous builds
2. Compile the plugin for ARM64 and x86_64
3. Validate the Audio Unit
4. Install to `/Library/Audio/Plug-Ins/Components/`

### Manual Installation

1. Open the Xcode project:
   ```bash
   open GSoloAU.xcodeproj
   ```

2. Build the **Release** target (Universal)

3. Copy the component:
   ```bash
   sudo cp -r build/Release/GSoloAU.component /Library/Audio/Plug-Ins/Components/
   sudo chmod -R 755 /Library/Audio/Plug-Ins/Components/GSoloAU.component
   sudo chown -R root:wheel /Library/Audio/Plug-Ins/Components/GSoloAU.component
   ```

4. Rescan Audio Units in your DAW

## Usage

### In Ableton Live 11

1. Open Ableton Live
2. Go to Preferences → Plug-Ins
3. Click "Rescan All Plug-Ins"
4. Look for "G-Solo" in the Instruments category

### In Logic Pro 11

1. Open Logic Pro
2. Go to Preferences → Plug-in Manager
3. Click "Rescan All Plug-Ins"
4. Look for "G-Solo" in the AU Instruments list

## Project Structure

```
GSoloARM_Source/
├── GSoloAU/                          # Source code
│   ├── GSoloAU.h                    # Main header
│   ├── GSoloAU.cpp                  # Main implementation
│   ├── GSoloAU_CocoaView.mm         # Cocoa UI implementation
│   ├── main.cpp                     # Entry point
│   ├── Contents/                    # Bundle resources
│   │   ├── Info.plist               # Bundle info
│   │   └── Resources/               # Images and resources (28 files)
│   └── AUInfo.plist                 # Audio Unit info
├── GSoloAU.xcodeproj/                # Xcode project
│   └── project.pbxproj
├── install.sh                       # Installation script
└── README.md                        # This file
```

## Building

### Command Line

```bash
xcodebuild -project GSoloAU.xcodeproj \
    -target GSoloAU \
    -configuration Release \
    ARCHS="arm64 x86_64" \
    ONLY_ACTIVE_ARCH=NO \
    MACOSX_DEPLOYMENT_TARGET=11.0
```

### Xcode

1. Open `GSoloAU.xcodeproj`
2. Select the **Release** scheme
3. Build (⌘B)

## Validation

Use `auval` to validate the Audio Unit:

```bash
# List all Audio Units
auval -l

# Validate G-Solo specifically
eauval -v /Library/Audio/Plug-Ins/Components/GSoloAU.component
```

## Troubleshooting

### Plugin Not Appearing

1. **Rescan Plug-Ins**: Most DAWs require a manual rescan after installation
2. **Check Installation**: Verify the component exists at `/Library/Audio/Plug-Ins/Components/GSoloAU.component`
3. **Validate**: Run `auval -v /Library/Audio/Plug-Ins/Components/GSoloAU.component`
4. **Permissions**: Ensure the component has correct permissions (755, owned by root:wheel)

### Compilation Errors

1. **Xcode Version**: Ensure you're using Xcode 14.0 or later
2. **SDK**: The project requires macOS 11.0 SDK or later
3. **Dependencies**: The project links against standard macOS frameworks (AudioToolbox, CoreFoundation, Cocoa, CoreAudio, Accelerate)

### Architecture Issues

To check the binary architecture:

```bash
file build/Release/GSoloAU.component/Contents/MacOS/GSoloAU
lipo -info build/Release/GSoloAU.component/Contents/MacOS/GSoloAU
```

The output should show both `arm64` and `x86_64` architectures.

## Technical Details

### Audio Unit Type

- **Type**: `kAudioUnitType_MusicDevice` (`aumu`)
- **SubType**: `'AkGs'` (matches original)
- **Manufacturer**: `'AkGs'` (matches original)

### Properties

| Property ID | Type | Description |
|-------------|------|-------------|
| `kGSoloAU_Property_Program` | UInt32 | Current program |
| `kGSoloAU_Property_Volume` | Float32 | Master volume (0.0 - 1.0) |
| `kGSoloAU_Property_Pan` | Float32 | Pan position (0.0 - 1.0) |
| `kGSoloAU_Property_SoloMode` | Boolean | Solo mode state |

### Parameters

| Parameter ID | Name | Range | Default |
|--------------|------|-------|---------|
| `kGSoloAU_Param_Volume` | Volume | 0.0 - 1.0 | 1.0 |
| `kGSoloAU_Param_Pan` | Pan | 0.0 - 1.0 | 0.5 |
| `kGSoloAU_Param_PitchBend` | Pitch Bend | -1.0 - 1.0 | 0.0 |
| `kGSoloAU_Param_Solo` | Solo Mode | 0.0 - 1.0 | 0.0 |

## Compatibility

### DAWs Tested
- ✅ Ableton Live 11.3.2
- ✅ Logic Pro 11
- ✅ GarageBand

### macOS Versions
- ✅ macOS 11.0 (Big Sur)
- ✅ macOS 12.0 (Monterey)
- ✅ macOS 13.0 (Ventura)
- ✅ macOS 14.0 (Sonoma)
- ✅ macOS 15.7.2 (Sequoia)

### Architectures
- ✅ ARM64 (Apple Silicon)
- ✅ x86_64 (Intel)

## Version History

- **v2.0.1** (Current)
  - Initial ARM64 port
  - Universal Binary support
  - Basic sample playback engine
  - Solo mode functionality
  - Cocoa-based UI

## Original Plugin Information

The original G-Solo plugin was developed by **Soundlib, Inc.** and was a popular sampler instrument for macOS. This port aims to preserve its functionality while adding native Apple Silicon support.

- Original Bundle ID: `com.soundlib.gsolo`
- Original Signature: `AkGs`
- Original Version: 2.0.1

## Differences from G-Player

While G-Player and G-Solo share many similarities, G-Solo has some unique features:

1. **Solo Mode**: Special mode that ensures only one note plays at a time (monophonic)
2. **Different Bundle ID**: `com.soundlib.gsolo` vs `com.soundlib.gplayer`
3. **Different Signature**: `'AkGs'` vs `'AkGm'`
4. **Resource Files**: G-Solo has 28 resource files vs G-Player's 45

## License

This project is a port of the original G-Solo plugin. The original plugin was proprietary software developed by Soundlib, Inc. This port is provided for educational and compatibility purposes.

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## Support

For support, please open an issue on the GitHub repository.
