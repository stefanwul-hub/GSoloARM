#!/bin/bash

# G-Solo ARM64 Audio Unit Installer
# This script compiles, validates, and installs the G-Solo Audio Unit plugin

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo -e "${RED}Error: This script must be run on macOS${NC}"
    exit 1
fi

# Check for Xcode command line tools
if ! xcode-select -p >/dev/null 2>&1; then
    echo -e "${RED}Error: Xcode command line tools not found${NC}"
    echo "Please install Xcode and run: xcode-select --install"
    exit 1
fi

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR"
BUILD_DIR="$PROJECT_DIR/build"
INSTALL_DIR="/Library/Audio/Plug-Ins/Components"
COMPONENT_NAME="GSoloAU.component"
COMPONENT_PATH="$BUILD_DIR/Release/$COMPONENT_NAME"
FINAL_PATH="$INSTALL_DIR/$COMPONENT_NAME"

# Version
VERSION="2.0.1"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}G-Solo ARM64 Audio Unit Installer v$VERSION${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Step 1: Clean
 echo -e "${YELLOW}[1/6] Cleaning previous builds...${NC}"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
echo -e "${GREEN}✓ Cleaned${NC}"
echo ""

# Step 2: Copy resources
 echo -e "${YELLOW}[2/6] Copying resources...${NC}"
mkdir -p "$PROJECT_DIR/GSoloAU/Contents/Resources"
if [ -d "$PROJECT_DIR/GSoloAU/Contents/Resources" ]; then
    # Resources already copied during extraction
    echo -e "${GREEN}✓ Resources ready${NC}"
else
    echo -e "${YELLOW}⚠ No resources found, using defaults${NC}"
fi
echo ""

# Step 3: Compile
 echo -e "${YELLOW}[3/6] Compiling for ARM64...${NC}"
cd "$PROJECT_DIR"

# Build for Release (Universal Binary - ARM64 + x86_64)
xcodebuild -project GSoloAU.xcodeproj \
    -target GSoloAU \
    -configuration Release \
    ARCHS="arm64 x86_64" \
    ONLY_ACTIVE_ARCH=NO \
    MACOSX_DEPLOYMENT_TARGET=11.0 \
    CODE_SIGN_IDENTITY="" \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGNING_ALLOWED=NO \
    2>&1 | grep -E "(Build succeeded|error|warning)" || true

if [ -f "$COMPONENT_PATH" ]; then
    echo -e "${GREEN}✓ Compilation successful${NC}"
else
    echo -e "${RED}✗ Compilation failed${NC}"
    echo "Trying with default settings..."
    xcodebuild -project GSoloAU.xcodeproj \
        -target GSoloAU \
        -configuration Release \
        ARCHS="arm64 x86_64" \
        ONLY_ACTIVE_ARCH=NO \
        2>&1 | tail -20
    
    if [ ! -f "$COMPONENT_PATH" ]; then
        echo -e "${RED}✗ Compilation failed. Please check Xcode settings.${NC}"
        exit 1
    fi
fi
echo ""

# Step 4: Validate
echo -e "${YELLOW}[4/6] Validating Audio Unit...${NC}"
if command -v auval >/dev/null 2>&1; then
    # Copy to temporary location for validation
    TEMP_VALIDATE_DIR="/tmp/GSoloAU_validate"
    rm -rf "$TEMP_VALIDATE_DIR"
    mkdir -p "$TEMP_VALIDATE_DIR"
    cp -r "$COMPONENT_PATH" "$TEMP_VALIDATE_DIR/"
    
    # Validate using auval
    echo "Running auval validation..."
    auval -v "$TEMP_VALIDATE_DIR/$COMPONENT_NAME" 2>&1 | grep -E "(PASS|FAIL|error|warning)" || echo "Validation completed (check auval output above)"
    
    # Clean up
    rm -rf "$TEMP_VALIDATE_DIR"
    
    echo -e "${GREEN}✓ Validation complete${NC}"
else
    echo -e "${YELLOW}⚠ auval not found, skipping validation${NC}"
fi
echo ""

# Step 5: Check architecture
echo -e "${YELLOW}[5/6] Checking binary architecture...${NC}"
if command -v file >/dev/null 2>&1; then
    file "$COMPONENT_PATH/Contents/MacOS/GSoloAU"
fi
if command -v lipo >/dev/null 2>&1; then
    lipo -info "$COMPONENT_PATH/Contents/MacOS/GSoloAU" || true
fi
echo -e "${GREEN}✓ Architecture check complete${NC}"
echo ""

# Step 6: Install
echo -e "${YELLOW}[6/6] Installing to $INSTALL_DIR...${NC}"

# Create install directory if it doesn't exist
if [ ! -d "$INSTALL_DIR" ]; then
    echo "Creating directory: $INSTALL_DIR"
    sudo mkdir -p "$INSTALL_DIR"
fi

# Remove old version if it exists (both possible names)
if [ -d "$FINAL_PATH" ]; then
    echo "Removing old version..."
    sudo rm -rf "$FINAL_PATH"
fi

# Also remove any old G-Solo.component
OLD_PATH="/Library/Audio/Plug-Ins/Components/G-Solo.component"
if [ -d "$OLD_PATH" ]; then
    echo "Removing old G-Solo.component..."
    sudo rm -rf "$OLD_PATH"
fi

# Copy new version
sudo cp -r "$COMPONENT_PATH" "$FINAL_PATH"

# Set permissions
sudo chmod -R 755 "$FINAL_PATH"
sudo chown -R root:wheel "$FINAL_PATH"

echo -e "${GREEN}✓ Installed to $FINAL_PATH${NC}"
echo ""

# Verify installation
if [ -f "$FINAL_PATH/Contents/MacOS/GSoloAU" ]; then
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}✓ G-Solo ARM64 installed successfully!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo "Plugin location: $FINAL_PATH"
    echo ""
    echo "To use in your DAW:"
    echo "  1. Restart Ableton Live / Logic Pro"
    echo "  2. Rescan Audio Units"
    echo "  3. Look for 'G-Solo' in the instrument list"
    echo ""
    echo "To uninstall:"
    echo "  sudo rm -rf $FINAL_PATH"
    echo ""
else
    echo -e "${RED}✗ Installation verification failed${NC}"
    exit 1
fi
