#pragma once

#include <AudioToolbox/AudioToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#include <Cocoa/Cocoa.h>

// G-Solo Audio Unit - Music Device (Sampler)

// Component description - MATCHES ORIGINAL
#define kGSoloAU_ComponentType kAudioUnitType_MusicDevice
#define kGSoloAU_ComponentSubType 'AkGs'  // Same as original G-Solo
#define kGSoloAU_ComponentManufacturer 'AkGs'  // Same as original

// Property IDs
enum {
    kGSoloAU_Property_Program = 1000,
    kGSoloAU_Property_ProgramName,
    kGSoloAU_Property_ProgramList,
    kGSoloAU_Property_LoadedSample,
    kGSoloAU_Property_PlayState,
    kGSoloAU_Property_Volume,
    kGSoloAU_Property_Pan,
    kGSoloAU_Property_PitchBend,
    kGSoloAU_Property_SoloMode  // Specific to G-Solo
};

// Parameter IDs
enum {
    kGSoloAU_Param_Volume = 0,
    kGSoloAU_Param_Pan = 1,
    kGSoloAU_Param_PitchBend = 2,
    kGSoloAU_Param_Expression = 3,
    kGSoloAU_Param_Solo = 4  // Solo parameter
};

// Custom view class
@interface GSoloAU_CocoaView : NSView
{
    IBOutlet NSView* contentView;
    IBOutlet NSSlider* volumeSlider;
    IBOutlet NSSlider* panSlider;
    IBOutlet NSButton* soloButton;
    IBOutlet NSTextField* programNameField;
    
    AudioUnit audioUnit;
    AudioUnitParameter parameterVolume;
    AudioUnitParameter parameterPan;
    AudioUnitParameter parameterSolo;
}

- (id)initWithAudioUnit:(AudioUnit)au;
- (void)setAudioUnit:(AudioUnit)au;
- (void)interfaceDidLoad;

@end

// Audio Unit class
class GSoloAU : public AUMultitimbralInstrumentBase
{
public:
    GSoloAU(AudioComponentInstance inComponentInstance);
    virtual ~GSoloAU();
    
    // Overrides
    virtual OSStatus Initialize() override;
    virtual OSStatus GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable) override;
    virtual OSStatus GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData) override;
    virtual OSStatus SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize) override;
    
    virtual OSStatus GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo) override;
    virtual OSStatus GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue) override;
    virtual OSStatus SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue) override;
    
    virtual OSStatus StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams) override;
    virtual OSStatus StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame) override;
    
    virtual OSStatus Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData) override;
    
    // Custom methods
    OSStatus LoadSample(const CFURLRef inFileURL);
    OSStatus SetProgram(UInt32 inProgram);
    OSStatus SetSoloMode(Boolean inSolo);
    
private:
    // Sample data
    struct SampleZone {
        Float32* sampleData;
        UInt32 sampleLength;
        Float64 sampleRate;
        UInt32 loopStart;
        UInt32 loopEnd;
    };
    
    std::vector<SampleZone> mSampleZones;
    UInt32 mCurrentProgram;
    Float32 mVolume;
    Float32 mPan;
    Float32 mPitchBend;
    Boolean mSoloMode;
    
    // Active notes
    struct ActiveNote {
        NoteInstanceID noteID;
        UInt32 noteNumber;
        Float32 velocity;
        UInt64 startFrame;
        SampleZone* zone;
    };
    
    std::vector<ActiveNote> mActiveNotes;
    
    // Simple oscillator for testing
    Float32 mPhase;
    Float32 mFrequency;
};

// Cocoa View Factory
class GSoloAU_CocoaViewFactory : public AudioUnitCocoaViewFactoryBase
{
public:
    GSoloAU_CocoaViewFactory(GSoloAU* inAudioUnit) : mAudioUnit(inAudioUnit) {}
    
    virtual CFStringRef GetViewClassName() override { return CFSTR("GSoloAU_CocoaView"); }
    virtual CFStringRef GetNibFileName() override { return CFSTR("GSoloAU"); }
    
private:
    GSoloAU* mAudioUnit;
};
