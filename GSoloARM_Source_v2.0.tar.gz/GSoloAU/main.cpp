#include <AudioToolbox/AudioToolbox.h>
#include "GSoloAU.h"

// MARK: - Component Entry Point

extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance)
{
    return new GSoloAU(inComponentInstance);
}

// MARK: - Component Description

// This is automatically registered by AudioToolbox
// The component description is defined in the Info.plist

// Component description:
// Type: kAudioUnitType_MusicDevice (aumu)
// SubType: 'AkGs' (matches original G-Solo)
// Manufacturer: 'AkGs' (matches original)

// MARK: - Factory Function

extern "C" AudioComponentMethod GSoloAU_Methods[] = {
    {kAudioUnitInitializeSelect, (AudioComponentMethodFunction)GSoloAU::Initialize},
    {kAudioUnitUninitializeSelect, (AudioComponentMethodFunction)GSoloAU::Uninitialize},
    {kAudioUnitGetPropertyInfoSelect, (AudioComponentMethodFunction)GSoloAU::GetPropertyInfo},
    {kAudioUnitGetPropertySelect, (AudioComponentMethodFunction)GSoloAU::GetProperty},
    {kAudioUnitSetPropertySelect, (AudioComponentMethodFunction)GSoloAU::SetProperty},
    {kAudioUnitAddPropertyListenerSelect, (AudioComponentMethodFunction)GSoloAU::AddPropertyListener},
    {kAudioUnitRemovePropertyListenerSelect, (AudioComponentMethodFunction)GSoloAU::RemovePropertyListener},
    {kAudioUnitGetParameterSelect, (AudioComponentMethodFunction)GSoloAU::GetParameter},
    {kAudioUnitSetParameterSelect, (AudioComponentMethodFunction)GSoloAU::SetParameter},
    {kAudioUnitScheduleParametersSelect, (AudioComponentMethodFunction)GSoloAU::ScheduleParameters},
    {kAudioUnitGetParameterValueSelect, (AudioComponentMethodFunction)GSoloAU::GetParameterValue},
    {kAudioUnitSetParameterValueSelect, (AudioComponentMethodFunction)GSoloAU::SetParameterValue},
    {kAudioUnitGetAllParameterValuesSelect, (AudioComponentMethodFunction)GSoloAU::GetAllParameterValues},
    {kAudioUnitStartNoteSelect, (AudioComponentMethodFunction)GSoloAU::StartNote},
    {kAudioUnitStopNoteSelect, (AudioComponentMethodFunction)GSoloAU::StopNote},
    {kAudioUnitRenderSelect, (AudioComponentMethodFunction)GSoloAU::Render},
    {0, nullptr}
};

// MARK: - Component Registration

// This is handled automatically by the Audio Unit framework
// when the component is loaded

// The component description:
// Type: kAudioUnitType_MusicDevice (aumu)
// SubType: 'AkGs'
// Manufacturer: 'AkGs'

// This matches the original G-Solo plugin
