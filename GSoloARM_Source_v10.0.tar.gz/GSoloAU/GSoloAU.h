#pragma once

#include <AudioToolbox/AudioToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#include <vector>

// Forward declarations for Objective-C types
@class NSView;

// Component description - MATCHES ORIGINAL
#define kGSoloAU_ComponentType kAudioUnitType_MusicDevice
#define kGSoloAU_ComponentSubType 'AkGs'  // Same as original G-Solo
#define kGSoloAU_ComponentManufacturer 'AkGs'  // Same as original

// Property IDs
enum {
    kGSoloAU_Property_Program = 1000,
    kGSoloAU_Property_ProgramName,
    kGSoloAU_Property_ProgramList,
    kGSoloAU_Property_LoadedSample,
    kGSoloAU_Property_PlayState,
    kGSoloAU_Property_Volume,
    kGSoloAU_Property_Pan,
    kGSoloAU_Property_PitchBend,
    kGSoloAU_Property_SoloMode  // Specific to G-Solo
};

// Parameter IDs
enum {
    kGSoloAU_Param_Volume = 0,
    kGSoloAU_Param_Pan = 1,
    kGSoloAU_Param_PitchBend = 2,
    kGSoloAU_Param_Expression = 3,
    kGSoloAU_Param_Solo = 4  // Solo parameter
};

// Sample zone structure
struct SampleZone {
    Float64 startFrame;
    Float64 endFrame;
    Float64 rootKey;
    Float64 tune;
    Float64 loopStart;
    Float64 loopEnd;
};

// Active note structure
struct ActiveNote {
    UInt32 noteID;
    UInt32 noteNumber;
    Float64 phase;
    Float64 frequency;
    Float64 velocity;
};

// Audio Unit class
class GSoloAU {
public:
    GSoloAU(AudioComponentInstance inComponentInstance);
    virtual ~GSoloAU();

    // Audio Unit methods
    virtual OSStatus Initialize();
    virtual OSStatus GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable);
    virtual OSStatus GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData);
    virtual OSStatus SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize);
    virtual OSStatus GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo);
    virtual OSStatus GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue);
    virtual OSStatus SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue);
    virtual OSStatus StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams);
    virtual OSStatus StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame);
    virtual OSStatus Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData);

    // Solo mode
    void SetSoloMode(Boolean inSolo);
    Boolean GetSoloMode() const;

    // View access
    NSView* GetView();
    void SetView(NSView* inView);

private:
    std::vector<SampleZone> mSampleZones;
    std::vector<ActiveNote> mActiveNotes;
    
    UInt32 mCurrentProgram;
    Float32 mVolume;
    Float32 mPan;
    Float32 mPitchBend;
    Boolean mSoloMode;
    Float64 mPhase;
    Float64 mFrequency;
    
    NSView* mCocoaView;
    AudioComponentInstance mComponentInstance;
};
