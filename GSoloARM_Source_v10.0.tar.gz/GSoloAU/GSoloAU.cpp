#include "GSoloAU.h"
#include <vector>
#include <cmath>

// MARK: - GSoloAU Implementation

GSoloAU::GSoloAU(AudioComponentInstance inComponentInstance)
: AUMultitimbralInstrumentBase(inComponentInstance, kGSoloAU_ComponentType, kGSoloAU_ComponentSubType, kGSoloAU_ComponentManufacturer)
, mCurrentProgram(0)
, mVolume(1.0f)
, mPan(0.5f)
, mPitchBend(0.0f)
, mSoloMode(false)
, mPhase(0.0f)
, mFrequency(440.0f)
{
    // Initialize with default values
    SetAUMaxFramesPerSlice(4096);
    
    // Set up default properties
    GlobalMIDIChannel = 0;
    
    // Create Cocoa view factory
    SetCocoaViewFactory(new GSoloAU_CocoaViewFactory(this));
}

GSoloAU::~GSoloAU()
{
    // Clean up sample data
    for (auto& zone : mSampleZones) {
        if (zone.sampleData) {
            free(zone.sampleData);
            zone.sampleData = nullptr;
        }
    }
    mSampleZones.clear();
}

OSStatus GSoloAU::Initialize()
{
    OSStatus result = AUMultitimbralInstrumentBase::Initialize();
    if (result != noErr) return result;
    
    // Initialize default program
    mCurrentProgram = 0;
    
    // Initialize sample zones (empty for now)
    // In a real implementation, we would load samples here
    
    return noErr;
}

// MARK: - Properties

OSStatus GSoloAU::GetPropertyInfo(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, UInt32& outDataSize, Boolean& outWritable)
{
    switch (inID) {
        case kAudioUnitProperty_StreamFormat:
            outDataSize = sizeof(AudioStreamBasicDescription);
            outWritable = false;
            return noErr;
            
        case kAudioUnitProperty_CPULoad:
            outDataSize = sizeof(Float32);
            outWritable = false;
            return noErr;
            
        case kAudioUnitProperty_Latency:
            outDataSize = sizeof(Float64);
            outWritable = false;
            return noErr;
            
        case kAudioUnitProperty_TailTime:
            outDataSize = sizeof(Float64);
            outWritable = false;
            return noErr;
            
        case kGSoloAU_Property_Program:
            outDataSize = sizeof(UInt32);
            outWritable = true;
            return noErr;
            
        case kGSoloAU_Property_Volume:
            outDataSize = sizeof(Float32);
            outWritable = true;
            return noErr;
            
        case kGSoloAU_Property_Pan:
            outDataSize = sizeof(Float32);
            outWritable = true;
            return noErr;
            
        case kGSoloAU_Property_SoloMode:
            outDataSize = sizeof(Boolean);
            outWritable = true;
            return noErr;
            
        default:
            return AUMultitimbralInstrumentBase::GetPropertyInfo(inID, inScope, inElement, outDataSize, outWritable);
    }
}

OSStatus GSoloAU::GetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, void* outData)
{
    switch (inID) {
        case kAudioUnitProperty_StreamFormat: {
            AudioStreamBasicDescription asbd;
            FillOutASBDForAudioUnitScope(GetOutput(0)->GetStreamFormat(), inScope, asbd);
            memcpy(outData, &asbd, sizeof(AudioStreamBasicDescription));
            return noErr;
        }
        
        case kAudioUnitProperty_CPULoad: {
            *(Float32*)outData = 0.0f; // TODO: Calculate actual CPU load
            return noErr;
        }
        
        case kAudioUnitProperty_Latency: {
            *(Float64*)outData = 0.0; // No latency
            return noErr;
        }
        
        case kAudioUnitProperty_TailTime: {
            *(Float64*)outData = 0.0; // No tail
            return noErr;
        }
        
        case kGSoloAU_Property_Program:
            *(UInt32*)outData = mCurrentProgram;
            return noErr;
            
        case kGSoloAU_Property_Volume:
            *(Float32*)outData = mVolume;
            return noErr;
            
        case kGSoloAU_Property_Pan:
            *(Float32*)outData = mPan;
            return noErr;
            
        case kGSoloAU_Property_SoloMode:
            *(Boolean*)outData = mSoloMode;
            return noErr;
            
        default:
            return AUMultitimbralInstrumentBase::GetProperty(inID, inScope, inElement, outData);
    }
}

OSStatus GSoloAU::SetProperty(AudioUnitPropertyID inID, AudioUnitScope inScope, AudioUnitElement inElement, const void* inData, UInt32 inDataSize)
{
    switch (inID) {
        case kGSoloAU_Property_Program: {
            UInt32 program = *(UInt32*)inData;
            return SetProgram(program);
        }
        
        case kGSoloAU_Property_Volume:
            mVolume = *(Float32*)inData;
            mVolume = std::max(0.0f, std::min(1.0f, mVolume));
            return noErr;
            
        case kGSoloAU_Property_Pan:
            mPan = *(Float32*)inData;
            mPan = std::max(0.0f, std::min(1.0f, mPan));
            return noErr;
            
        case kGSoloAU_Property_SoloMode:
            mSoloMode = *(Boolean*)inData;
            return noErr;
            
        default:
            return AUMultitimbralInstrumentBase::SetProperty(inID, inScope, inElement, inData, inDataSize);
    }
}

// MARK: - Parameters

OSStatus GSoloAU::GetParameterInfo(AudioUnitScope inScope, AudioUnitParameterID inParameterID, AudioUnitParameterInfo& outParameterInfo)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            outParameterInfo.flags = kAudioUnitParameterFlag_IsGlobal | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 1.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_LinearGain;
            outParameterInfo.cfNameString = CFSTR("Volume");
            return noErr;
            
        case kGSoloAU_Param_Pan:
            outParameterInfo.flags = kAudioUnitParameterFlag_IsGlobal | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 0.5f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Pan;
            outParameterInfo.cfNameString = CFSTR("Pan");
            return noErr;
            
        case kGSoloAU_Param_PitchBend:
            outParameterInfo.flags = kAudioUnitParameterFlag_IsGlobal | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = -1.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 0.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Cents;
            outParameterInfo.cfNameString = CFSTR("Pitch Bend");
            return noErr;
            
        case kGSoloAU_Param_Solo:
            outParameterInfo.flags = kAudioUnitParameterFlag_IsGlobal | kAudioUnitParameterFlag_IsWritable | kAudioUnitParameterFlag_HasCFNameString;
            outParameterInfo.minValue = 0.0f;
            outParameterInfo.maxValue = 1.0f;
            outParameterInfo.defaultValue = 0.0f;
            outParameterInfo.unit = kAudioUnitParameterUnit_Boolean;
            outParameterInfo.cfNameString = CFSTR("Solo");
            return noErr;
            
        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::GetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32& outValue)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            outValue = mVolume;
            return noErr;
            
        case kGSoloAU_Param_Pan:
            outValue = mPan;
            return noErr;
            
        case kGSoloAU_Param_PitchBend:
            outValue = mPitchBend;
            return noErr;
            
        case kGSoloAU_Param_Solo:
            outValue = mSoloMode ? 1.0f : 0.0f;
            return noErr;
            
        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

OSStatus GSoloAU::SetParameterValue(AudioUnitScope inScope, AudioUnitParameterID inParameterID, Float32 inValue)
{
    switch (inParameterID) {
        case kGSoloAU_Param_Volume:
            mVolume = std::max(0.0f, std::min(1.0f, inValue));
            return noErr;
            
        case kGSoloAU_Param_Pan:
            mPan = std::max(0.0f, std::min(1.0f, inValue));
            return noErr;
            
        case kGSoloAU_Param_PitchBend:
            mPitchBend = std::max(-1.0f, std::min(1.0f, inValue));
            return noErr;
            
        case kGSoloAU_Param_Solo:
            mSoloMode = (inValue > 0.5f);
            return noErr;
            
        default:
            return kAudioUnitErr_InvalidParameter;
    }
}

// MARK: - Note Handling

OSStatus GSoloAU::StartNote(MusicDeviceInstrumentID inInstrument, MusicDeviceGroupID inGroupID, NoteInstanceID* outNoteInstanceID, UInt32 inOffsetSampleFrame, const MusicDeviceNoteParams& inParams)
{
    // In Solo mode, stop all other notes
    if (mSoloMode) {
        for (auto it = mActiveNotes.begin(); it != mActiveNotes.end(); ) {
            if (it->noteID != *outNoteInstanceID) {
                // Stop the note
                StopNote(inGroupID, it->noteID, inOffsetSampleFrame);
                it = mActiveNotes.erase(it);
            } else {
                ++it;
            }
        }
    }
    
    // Create a new note
    ActiveNote note;
    note.noteID = (NoteInstanceID)this; // Simple ID generation
    note.noteNumber = inParams.mPitch;
    note.velocity = inParams.mVelocity;
    note.startFrame = GetCurrentHostTimeSampleFrame();
    note.zone = nullptr; // No sample zone for now
    
    mActiveNotes.push_back(note);
    *outNoteInstanceID = note.noteID;
    
    // Calculate frequency from note number
    mFrequency = 440.0f * powf(2.0f, (inParams.mPitch - 69) / 12.0f);
    mPhase = 0.0f;
    
    return noErr;
}

OSStatus GSoloAU::StopNote(MusicDeviceGroupID inGroupID, NoteInstanceID inNoteInstanceID, UInt32 inOffsetSampleFrame)
{
    // Remove the note
    for (auto it = mActiveNotes.begin(); it != mActiveNotes.end(); ++it) {
        if (it->noteID == inNoteInstanceID) {
            mActiveNotes.erase(it);
            break;
        }
    }
    
    return noErr;
}

// MARK: - Audio Rendering

OSStatus GSoloAU::Render(AudioUnitRenderActionFlags& ioActionFlags, const AudioTimeStamp& inTimeStamp, UInt32 inOutputBusNumber, UInt32 inNumberFrames, AudioBufferList& ioData)
{
    // Get output buffer
    Float32* outBuffer = (Float32*)ioData.mBuffers[0].mData;
    
    // Simple sine wave generator for testing
    // In a real implementation, this would play back samples
    Float32 sampleRate = GetOutput(0)->GetStreamFormat().mSampleRate;
    Float32 phaseIncrement = 2.0f * M_PI * mFrequency / sampleRate;
    
    for (UInt32 i = 0; i < inNumberFrames; ++i) {
        // Generate sine wave
        Float32 sample = sinf(mPhase) * mVolume;
        
        // Apply pan (simple stereo panning)
        Float32 leftGain = (mPan <= 0.5f) ? 1.0f : 2.0f * (1.0f - mPan);
        Float32 rightGain = (mPan >= 0.5f) ? 1.0f : 2.0f * mPan;
        
        // For mono output, just use average
        outBuffer[i] = sample * (leftGain + rightGain) * 0.5f;
        
        // Update phase
        mPhase += phaseIncrement;
        if (mPhase >= 2.0f * M_PI) {
            mPhase -= 2.0f * M_PI;
        }
    }
    
    return noErr;
}

// MARK: - Sample Loading

OSStatus GSoloAU::LoadSample(const CFURLRef inFileURL)
{
    // TODO: Implement sample loading
    // For now, just create a dummy sample zone
    SampleZone zone;
    zone.sampleData = nullptr;
    zone.sampleLength = 0;
    zone.sampleRate = 44100.0;
    zone.loopStart = 0;
    zone.loopEnd = 0;
    
    mSampleZones.push_back(zone);
    
    return noErr;
}

OSStatus GSoloAU::SetProgram(UInt32 inProgram)
{
    if (inProgram >= mSampleZones.size()) {
        return kAudioUnitErr_InvalidPropertyValue;
    }
    
    mCurrentProgram = inProgram;
    return noErr;
}

OSStatus GSoloAU::SetSoloMode(Boolean inSolo)
{
    mSoloMode = inSolo;
    return noErr;
}

// MARK: - Cocoa View Factory

OSStatus GSoloAU_CocoaViewFactory::CreateCocoaAUView(AudioUnit inAudioUnit, const Rect& inBounds, CFStringRef inViewCFString, NSView** outView)
{
    if (CFStringCompare(inViewCFString, GetViewClassName(), 0) != kCFCompareEqualTo) {
        return kAudioUnitErr_InvalidPropertyValue;
    }
    
    // Create the view
    GSoloAU_CocoaView* view = [[GSoloAU_CocoaView alloc] initWithFrame:NSMakeRect(inBounds.left, inBounds.top, inBounds.right - inBounds.left, inBounds.bottom - inBounds.top)];
    [view setAudioUnit:inAudioUnit];
    [view interfaceDidLoad];
    
    *outView = view;
    return noErr;
}
