#import "GSoloAU.h"
#import <Cocoa/Cocoa.h>

// MARK: - Cocoa View Implementation

@implementation GSoloAU_CocoaView
{
    GSoloAU* audioUnit;
    AudioUnitParameter parameterVolume;
    AudioUnitParameter parameterPan;
    AudioUnitParameter parameterSolo;
}

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialize
        audioUnit = nullptr;
        parameterVolume = nullptr;
        parameterPan = nullptr;
        parameterSolo = nullptr;
    }
    return self;
}

- (id)initWithAudioUnit:(GSoloAU*)au
{
    self = [super initWithFrame:NSMakeRect(0, 0, 400, 300)];
    if (self) {
        audioUnit = au;
        [self interfaceDidLoad];
    }
    return self;
}

- (void)setAudioUnit:(GSoloAU*)au
{
    audioUnit = au;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)interfaceDidLoad
{
    // Create a simple UI programmatically
    // (In a real implementation, we would load from a nib)
    
    // Background color
    [self setWantsLayer:YES];
    [[self layer] setBackgroundColor:[NSColor colorWithRed:0.15 green:0.15 blue:0.18 alpha:1.0].CGColor];
    
    // Title label
    NSTextField* titleLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(20, 260, 360, 24)];
    [titleLabel setStringValue:@"G-Solo"];
    [titleLabel setBezeled:NO];
    [titleLabel setDrawsBackground:NO];
    [titleLabel setEditable:NO];
    [titleLabel setSelectable:NO];
    [titleLabel setTextColor:[NSColor whiteColor]];
    [titleLabel setFont:[NSFont boldSystemFontOfSize:18]];
    [titleLabel setAlignment:NSTextAlignmentCenter];
    [self addSubview:titleLabel];
    [titleLabel release];
    
    // Volume label
    NSTextField* volumeLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(20, 210, 100, 17)];
    [volumeLabel setStringValue:@"Volume:"];
    [volumeLabel setBezeled:NO];
    [volumeLabel setDrawsBackground:NO];
    [volumeLabel setEditable:NO];
    [volumeLabel setSelectable:NO];
    [volumeLabel setTextColor:[NSColor whiteColor]];
    [self addSubview:volumeLabel];
    [volumeLabel release];
    
    // Volume slider
    volumeSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(120, 210, 200, 20)];
    [volumeSlider setMinValue:0.0];
    [volumeSlider setMaxValue:1.0];
    [volumeSlider setFloatValue:1.0];
    [volumeSlider setTarget:self];
    [volumeSlider setAction:@selector(volumeChanged:)];
    [self addSubview:volumeSlider];
    [volumeSlider release];
    
    // Pan label
    NSTextField* panLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(20, 170, 100, 17)];
    [panLabel setStringValue:@"Pan:"];
    [panLabel setBezeled:NO];
    [panLabel setDrawsBackground:NO];
    [panLabel setEditable:NO];
    [panLabel setSelectable:NO];
    [panLabel setTextColor:[NSColor whiteColor]];
    [self addSubview:panLabel];
    [panLabel release];
    
    // Pan slider
    panSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(120, 170, 200, 20)];
    [panSlider setMinValue:0.0];
    [panSlider setMaxValue:1.0];
    [panSlider setFloatValue:0.5];
    [panSlider setTarget:self];
    [panSlider setAction:@selector(panChanged:)];
    [self addSubview:panSlider];
    [panSlider release];
    
    // Solo button
    soloButton = [[NSButton alloc] initWithFrame:NSMakeRect(120, 130, 200, 30)];
    [soloButton setTitle:@"Solo Mode: OFF"];
    [soloButton setButtonType:NSPushOnPushOffButton];
    [soloButton setState:NSOffState];
    [soloButton setTarget:self];
    [soloButton setAction:@selector(soloChanged:)];
    [soloButton setBezelStyle:NSBezelStyleRegularSquare];
    [self addSubview:soloButton];
    [soloButton release];
    
    // Program name label
    programNameField = [[NSTextField alloc] initWithFrame:NSMakeRect(20, 90, 360, 20)];
    [programNameField setStringValue:@"Program: Init"];
    [programNameField setBezeled:NO];
    [programNameField setDrawsBackground:NO];
    [programNameField setEditable:NO];
    [programNameField setSelectable:NO];
    [programNameField setTextColor:[NSColor whiteColor]];
    [programNameField setAlignment:NSTextAlignmentCenter];
    [self addSubview:programNameField];
    [programNameField release];
    
    // Info label
    NSTextField* infoLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(20, 50, 360, 40)];
    [infoLabel setStringValue:@"G-Solo ARM64\nSoundlib, Inc."];
    [infoLabel setBezeled:NO];
    [infoLabel setDrawsBackground:NO];
    [infoLabel setEditable:NO];
    [infoLabel setSelectable:NO];
    [infoLabel setTextColor:[NSColor colorWithWhite:0.7 alpha:1.0]];
    [infoLabel setAlignment:NSTextAlignmentCenter];
    [infoLabel setFont:[NSFont systemFontOfSize:12]];
    [self addSubview:infoLabel];
    [infoLabel release];
    
    // Update parameter references
    if (audioUnit) {
        AudioUnitParameter param;
        UInt32 paramID = kGSoloAU_Param_Volume;
        OSStatus result = AudioUnitGetParameter(audioUnit, paramID, kAudioUnitScope_Global, 0, &param);
        if (result == noErr) {
            parameterVolume = param;
        }
        
        paramID = kGSoloAU_Param_Pan;
        result = AudioUnitGetParameter(audioUnit, paramID, kAudioUnitScope_Global, 0, &param);
        if (result == noErr) {
            parameterPan = param;
        }
        
        paramID = kGSoloAU_Param_Solo;
        result = AudioUnitGetParameter(audioUnit, paramID, kAudioUnitScope_Global, 0, &param);
        if (result == noErr) {
            parameterSolo = param;
        }
    }
}

- (void)volumeChanged:(id)sender
{
    if (audioUnit) {
        Float32 value = [volumeSlider floatValue];
        AudioUnitSetParameter(audioUnit, kGSoloAU_Param_Volume, kAudioUnitScope_Global, 0, value, 0);
    }
}

- (void)panChanged:(id)sender
{
    if (audioUnit) {
        Float32 value = [panSlider floatValue];
        AudioUnitSetParameter(audioUnit, kGSoloAU_Param_Pan, kAudioUnitScope_Global, 0, value, 0);
    }
}

- (void)soloChanged:(id)sender
{
    if (audioUnit) {
        NSInteger state = [soloButton state];
        Float32 value = (state == NSOnState) ? 1.0f : 0.0f;
        AudioUnitSetParameter(audioUnit, kGSoloAU_Param_Solo, kAudioUnitScope_Global, 0, value, 0);
        [soloButton setTitle:(state == NSOnState) ? @"Solo Mode: ON" : @"Solo Mode: OFF"];
    }
}

- (void)updateUI
{
    if (audioUnit && volumeSlider) {
        Float32 volume;
        AudioUnitGetParameter(audioUnit, kGSoloAU_Param_Volume, kAudioUnitScope_Global, 0, &volume);
        [volumeSlider setFloatValue:volume];
    }
    
    if (audioUnit && panSlider) {
        Float32 pan;
        AudioUnitGetParameter(audioUnit, kGSoloAU_Param_Pan, kAudioUnitScope_Global, 0, &pan);
        [panSlider setFloatValue:pan];
    }
    
    if (audioUnit && soloButton) {
        Float32 solo;
        AudioUnitGetParameter(audioUnit, kGSoloAU_Param_Solo, kAudioUnitScope_Global, 0, &solo);
        [soloButton setState:(solo > 0.5f) ? NSOnState : NSOffState];
        [soloButton setTitle:(solo > 0.5f) ? @"Solo Mode: ON" : @"Solo Mode: OFF"];
    }
}

@end
