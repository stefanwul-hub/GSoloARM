#include <AudioToolbox/AudioToolbox.h>
#include "GSoloAU.h"

// MARK: - Component Entry Point

extern "C" void* GSoloAU_Create(AudioComponentInstance inComponentInstance)
{
    return new GSoloAU(inComponentInstance);
}

// MARK: - Component Description

// Component description:
// Type: kAudioUnitType_MusicDevice (aumu)
// SubType: 'AkGs' (matches original G-Solo)
// Manufacturer: 'AkGs' (matches original)

// MARK: - Factory Function

extern "C" AudioComponentMethod GSoloAU_Methods[] = {
    {kAudioUnitInitializeSelect, (AudioComponentMethodFunction)&GSoloAU::Initialize},
    {kAudioUnitUninitializeSelect, (AudioComponentMethodFunction)&GSoloAU::Uninitialize},
    {kAudioUnitGetPropertyInfoSelect, (AudioComponentMethodFunction)&GSoloAU::GetPropertyInfo},
    {kAudioUnitGetPropertySelect, (AudioComponentMethodFunction)&GSoloAU::GetProperty},
    {kAudioUnitSetPropertySelect, (AudioComponentMethodFunction)&GSoloAU::SetProperty},
    {kAudioUnitGetParameterSelect, (AudioComponentMethodFunction)&GSoloAU::GetParameter},
    {kAudioUnitSetParameterSelect, (AudioComponentMethodFunction)&GSoloAU::SetParameter},
    {kAudioUnitGetParameterValueSelect, (AudioComponentMethodFunction)&GSoloAU::GetParameterValue},
    {kAudioUnitSetParameterValueSelect, (AudioComponentMethodFunction)&GSoloAU::SetParameterValue},
    {kAudioUnitStartNoteSelect, (AudioComponentMethodFunction)&GSoloAU::StartNote},
    {kAudioUnitStopNoteSelect, (AudioComponentMethodFunction)&GSoloAU::StopNote},
    {kAudioUnitRenderSelect, (AudioComponentMethodFunction)&GSoloAU::Render},
    {0, nullptr}
};

// MARK: - Component Registration

// This is handled automatically by the Audio Unit framework
// when the component is loaded
