#import <Cocoa/Cocoa.h>

// Forward declaration of C++ class
class GSoloAU;

// MARK: - Cocoa View Interface

@interface GSoloAU_CocoaView : NSView
{
    GSoloAU* audioUnit;
    IBOutlet NSView* contentView;
    IBOutlet NSSlider* volumeSlider;
    IBOutlet NSSlider* panSlider;
    IBOutlet NSButton* soloButton;
    IBOutlet NSTextField* programNameField;
}

- (id)initWithAudioUnit:(GSoloAU*)au;
- (void)setAudioUnit:(GSoloAU*)au;
- (void)interfaceDidLoad;

@end

// MARK: - Cocoa View Implementation

@implementation GSoloAU_CocoaView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        audioUnit = nullptr;
    }
    return self;
}

- (id)initWithAudioUnit:(GSoloAU*)au
{
    self = [super initWithFrame:NSMakeRect(0, 0, 400, 300)];
    if (self) {
        audioUnit = au;
        [self interfaceDidLoad];
    }
    return self;
}

- (void)setAudioUnit:(GSoloAU*)au
{
    audioUnit = au;
}

- (void)interfaceDidLoad
{
    // Create a simple UI programmatically
    NSRect frame = [self frame];
    
    // Background color
    [self setWantsLayer:YES];
    [[self layer] setBackgroundColor:[NSColor colorWithRed:0.15 green:0.15 blue:0.18 alpha:1.0].CGColor];
    
    // Volume slider
    volumeSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(20, frame.size.height - 40, 180, 20)];
    [volumeSlider setMinValue:0.0];
    [volumeSlider setMaxValue:1.0];
    [volumeSlider setFloatValue:1.0];
    [volumeSlider setTarget:self];
    [volumeSlider setAction:@selector(volumeChanged:)];
    [self addSubview:volumeSlider];
    
    // Volume label
    NSTextField* volumeLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(20, frame.size.height - 20, 100, 16)];
    [volumeLabel setStringValue:@"Volume:"];
    [volumeLabel setBezeled:NO];
    [volumeLabel setDrawsBackground:NO];
    [volumeLabel setEditable:NO];
    [volumeLabel setSelectable:NO];
    [volumeLabel setTextColor:[NSColor whiteColor]];
    [self addSubview:volumeLabel];
    
    // Pan slider
    panSlider = [[NSSlider alloc] initWithFrame:NSMakeRect(20, frame.size.height - 70, 180, 20)];
    [panSlider setMinValue:0.0];
    [panSlider setMaxValue:1.0];
    [panSlider setFloatValue:0.5];
    [panSlider setTarget:self];
    [panSlider setAction:@selector(panChanged:)];
    [self addSubview:panSlider];
    
    // Pan label
    NSTextField* panLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(20, frame.size.height - 50, 100, 16)];
    [panLabel setStringValue:@"Pan:"];
    [panLabel setBezeled:NO];
    [panLabel setDrawsBackground:NO];
    [panLabel setEditable:NO];
    [panLabel setSelectable:NO];
    [panLabel setTextColor:[NSColor whiteColor]];
    [self addSubview:panLabel];
    
    // Solo button
    soloButton = [[NSButton alloc] initWithFrame:NSMakeRect(20, frame.size.height - 100, 100, 24)];
    [soloButton setTitle:@"Solo Mode"];
    [soloButton setButtonType:NSOnOffButton];
    [soloButton setState:NSOffState];
    [soloButton setTarget:self];
    [soloButton setAction:@selector(soloChanged:)];
    [self addSubview:soloButton];
    
    // Program name
    programNameField = [[NSTextField alloc] initWithFrame:NSMakeRect(20, frame.size.height - 130, 180, 16)];
    [programNameField setStringValue:@"G-Solo"];
    [programNameField setBezeled:NO];
    [programNameField setDrawsBackground:NO];
    [programNameField setEditable:NO];
    [programNameField setSelectable:NO];
    [programNameField setTextColor:[NSColor whiteColor]];
    [self addSubview:programNameField];
}

- (void)volumeChanged:(id)sender
{
    if (audioUnit) {
        audioUnit->SetParameterValue(kAudioUnitScope_Global, 0, [sender floatValue]);
    }
}

- (void)panChanged:(id)sender
{
    if (audioUnit) {
        audioUnit->SetParameterValue(kAudioUnitScope_Global, 1, [sender floatValue]);
    }
}

- (void)soloChanged:(id)sender
{
    if (audioUnit) {
        audioUnit->SetSoloMode([sender state] == NSOnState);
    }
}

@end

// MARK: - C Function for creating the Cocoa view

extern "C" void* CreateGSoloAUCocoaView(void* au)
{
    GSoloAU_CocoaView* view = [[GSoloAU_CocoaView alloc] initWithAudioUnit:(GSoloAU*)au];
    return (void*)CFBridgingRetain(view);
}
